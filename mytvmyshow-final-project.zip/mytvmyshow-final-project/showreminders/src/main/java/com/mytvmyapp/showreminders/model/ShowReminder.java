package com.mytvmyapp.showreminders.model;


	public class ShowReminder {
		
		
	String channelName;
	String name;
	String type;
	String scheduledTime;
	

	public ShowReminder()
	{

	}
	public ShowReminder(String channelName, String name, String type, String scheduledTime) {
	super();
	this.channelName = channelName;
	this.name = name;
	this.type = type;
	this.scheduledTime = scheduledTime;
	
	}

	public String getChannelName() {
	return channelName;
	}
	public void setChannelName(String channelName) {
	this.channelName = channelName;
	}
	public String getName() {
	return name;
	}
	public void setName(String name) {
	this.name = name;
	}
	public String getType() {
	return type;
	}
	public void setType(String type) {
	this.type = type;
	}
	public String getScheduledTime() {
	return scheduledTime;
	}
	public void setScheduledTime(String scheduledTime) {
	this.scheduledTime = scheduledTime;
	}
	
	@Override
	public String toString() {
	return "ShowReminder [channelName=" + channelName + ", name=" + name + ", type=" + type
	+ ", scheduledTime=" + scheduledTime  + "]";
	}


	}