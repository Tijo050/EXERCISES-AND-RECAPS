package com.mytvmyapp.showreminders.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mytvmyapp.showreminders.exception.ShowAlreadyAdded;
import com.mytvmyapp.showreminders.exception.ShowNotFound;
import com.mytvmyapp.showreminders.model.ShowReminder;
import com.mytvmyapp.showreminders.service.ShowReminderService;

@RestController
@CrossOrigin("*")
@RequestMapping("/mytv/myapp")
public class Controller 
{
	@Autowired
	ShowReminderService service;
	@PostMapping("/addshow/{userId}")
	public ResponseEntity<?> addShow(@RequestBody ShowReminder showreminder, @PathVariable("userId") String uid)
	{
		ShowReminder result;
		try
		{	
		result=service.add(showreminder,uid);
		return new ResponseEntity<ShowReminder>(result,HttpStatus.CREATED);
		}
		catch (ShowAlreadyAdded e) 
		{
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}
	@GetMapping("/viewshows/{userId}")
	public ResponseEntity<?> viewshows(@PathVariable("userId") String userId)
	{
	List<ShowReminder> resultlist=service.viewShows(userId);
	System.out.println(resultlist);
	return new ResponseEntity<>(resultlist,HttpStatus.OK);
	}
	
	@DeleteMapping("/remove/{showName}/{userId}")
	public ResponseEntity<?> removeshow(@PathVariable("showName") String showname,@PathVariable("userId") String user)
	{
		try
		{
		service.deleteshow(showname,user);
		return new ResponseEntity<String>("Removed Successfully",HttpStatus.OK);
		}
		catch(ShowNotFound e)
		{
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);

		}

	}
//	@GetMapping("/findshow/{showName}/{userId}")
//	public ResponseEntity findShow(@PathVariable("showName") String showname,@PathVariable("userId") String userId)
//	{
//		service.findShow(showname,userId);
//		return new ResponseEntity<String>(showname,HttpStatus.OK);
//
//	}

	
	
}
