package com.mytvmyapp.showreminders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import com.mytvmyapp.showreminders.filter.remindertoken;


@EnableEurekaClient
@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages = "com.mytvmyapp.showreminders")
public class ShowremindersApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(ShowremindersApplication.class, args);
		
	}
	    
	    @Bean
	    public FilterRegistrationBean<remindertoken> jwtFilter()
	    {
	        UrlBasedCorsConfigurationSource urlconfig=new UrlBasedCorsConfigurationSource();
	        CorsConfiguration config=new CorsConfiguration();
	        config.setAllowCredentials(true);
	        config.addAllowedOrigin("*");
	        config.addAllowedMethod("*");
	        config.addAllowedHeader("*");
	        urlconfig.registerCorsConfiguration("/**", config);
	        FilterRegistrationBean filterbean=new FilterRegistrationBean(new CorsFilter(urlconfig));
	        filterbean.setFilter(new remindertoken());
	        filterbean.addUrlPatterns("/mytv/myapp*");
	        return filterbean;
	    }
	}


