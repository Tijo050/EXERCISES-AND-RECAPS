package com.mytvmyapp.showreminders.service;

import java.util.List;

import com.mytvmyapp.showreminders.exception.ShowAlreadyAdded;
import com.mytvmyapp.showreminders.exception.ShowNotFound;
import com.mytvmyapp.showreminders.model.ShowReminder;

public interface ShowReminderService 
{
	ShowReminder add(ShowReminder showreminder, String userId) throws ShowAlreadyAdded;
	List<ShowReminder> viewShows(String userId);
	boolean deleteshow(String showName,String userId) throws ShowNotFound;
//	ShowReminder findShow(String showName,String userId);

}
