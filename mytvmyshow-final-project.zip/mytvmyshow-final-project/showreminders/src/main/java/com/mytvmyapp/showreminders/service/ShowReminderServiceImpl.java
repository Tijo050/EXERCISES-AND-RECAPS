package com.mytvmyapp.showreminders.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mytvmyapp.showreminders.exception.ShowAlreadyAdded;
import com.mytvmyapp.showreminders.exception.ShowNotFound;
import com.mytvmyapp.showreminders.model.ShowReminder;
import com.mytvmyapp.showreminders.model.User;
import com.mytvmyapp.showreminders.repo.ShowRemindersrepo;
 
@Service
public class ShowReminderServiceImpl implements ShowReminderService
{
	@Autowired
	ShowRemindersrepo repo;
	@Override
	public ShowReminder add(ShowReminder showreminder, String userId) throws ShowAlreadyAdded
	{
		User user;
		Optional<User> userexist=repo.findById(userId);
		if(userexist.isPresent())
		{
			 user=userexist.get();
		}
		else
		{
			 user=new User();
			user.setUserId(userId);
		}
		
		List<ShowReminder> listofshows=user.getListofShows();	
		if(listofshows==null || listofshows.isEmpty())
		{
			listofshows = new ArrayList<>();	
		}
		Optional<ShowReminder> reminder=listofshows.stream().filter(obj ->obj.getName().equalsIgnoreCase(showreminder.getName())).findAny();
		if(reminder.isPresent())
			throw new ShowAlreadyAdded("Show Already Exists");
		
			ShowReminder result=new ShowReminder();
			result.setChannelName(showreminder.getChannelName());
			
			result.setScheduledTime(showreminder.getScheduledTime());
			result.setName(showreminder.getName());
			
			result.setType(showreminder.getType());
			listofshows.add(result);
			user.setListofShows(listofshows);
			repo.save(user);
			return result;
	}
	
	@Override
	public List<ShowReminder> viewShows(String userId) 
	{
		List<ShowReminder> reminder=null;
		Optional<User> userexist=repo.findById(userId);
		if(userexist.isPresent())
		{
			User user=userexist.get();
			 reminder=user.getListofShows();
		}
		return reminder;
	}
	
	@Override
	public boolean deleteshow(String showName,String userId) throws ShowNotFound 
	{
		List<ShowReminder> reminder=null;
		ShowReminder showreminder=null;
		User user=null;
		Optional<User> userexist=repo.findById(userId);
		if(userexist.isPresent())
		{
			 user=userexist.get();
			reminder=user.getListofShows();
		}
		if(reminder!=null)
		{
			Optional<ShowReminder> result=reminder.stream().filter(obj -> obj.getName().equalsIgnoreCase(showName)).findAny();
			if(result.isPresent())
			{
				showreminder=result.get();
				
			}
		}
		
		if(showreminder==null)
			throw new ShowNotFound("show not found");
		
		reminder.remove(showreminder);
		user.setListofShows(reminder);
		repo.save(user);
		return true;	
	}

//	@Override
//	public ShowReminder findShow(String showName, String userId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
	
	


}
