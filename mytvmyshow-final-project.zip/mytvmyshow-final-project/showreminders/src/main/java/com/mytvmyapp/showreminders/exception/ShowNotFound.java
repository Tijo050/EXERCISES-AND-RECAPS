package com.mytvmyapp.showreminders.exception;

public class ShowNotFound extends Exception
{

	public ShowNotFound(String message) 
	{
		super(message);
	}

}
