package com.mytvmyapp.showreminders.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document
public class User {
	@Id
	String userId;
	List<ShowReminder> listofShows;
	
	public User() 
	{
		
	}
	public User(String userId, List<ShowReminder> listofShows) {
		super();
		this.userId = userId;
		this.listofShows = listofShows;
	}

	public String getUserId() 
	{
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<ShowReminder> getListofShows() {
		return listofShows;
	}

	public void setListofShows(List<ShowReminder> listofShows) {
		this.listofShows = listofShows;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", listofShows=" + listofShows + "]";
	}
	
	

}
