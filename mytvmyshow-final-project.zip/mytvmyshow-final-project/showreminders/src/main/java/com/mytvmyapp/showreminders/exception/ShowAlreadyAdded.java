package com.mytvmyapp.showreminders.exception;

public class ShowAlreadyAdded extends Exception
{

	public ShowAlreadyAdded(String message)
	{
		super(message);
	}

}
