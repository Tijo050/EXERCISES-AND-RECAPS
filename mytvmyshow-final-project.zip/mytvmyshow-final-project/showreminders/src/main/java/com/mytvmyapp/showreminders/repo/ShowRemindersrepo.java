package com.mytvmyapp.showreminders.repo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.mytvmyapp.showreminders.model.User;

@Repository
public interface ShowRemindersrepo extends MongoRepository<User,String>
{
	
}
