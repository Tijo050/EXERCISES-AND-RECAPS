package com.mytvmyapp.showreminders.service;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.annotation.Rollback;

import com.mytvmyapp.showreminders.exception.ShowAlreadyAdded;
import com.mytvmyapp.showreminders.exception.ShowNotFound;
import com.mytvmyapp.showreminders.model.ShowReminder;
import com.mytvmyapp.showreminders.model.User;
import com.mytvmyapp.showreminders.repo.ShowRemindersrepo;

public class ShowReminderServiceImplTest 
{
	@Mock
	private ShowRemindersrepo showrepo;
	@InjectMocks
	private ShowReminderServiceImpl showservice;
	
	private User user,newUser;
	private ShowReminder showreminder;
	private List<ShowReminder> showlist;
    Optional<User> options;
    private List<User> userList=new ArrayList<>();
	@BeforeEach
	public void setUp() throws Exception {

		MockitoAnnotations.initMocks(this);
		user=new User();
		showlist = new ArrayList<ShowReminder>();
		showreminder = new ShowReminder("Zee TV","kuch kuch hotha hai","movie","20/07/2021");
		ShowReminder showreminder1 = new ShowReminder("MAA TV","Dance Plus","Show","22/07/2021");
		ShowReminder showreminder2 = new ShowReminder("Colors TV HD","Meri Aashiqui","show","10/00/00");
		showlist.add(showreminder1);
		showlist.add(showreminder2);
		user.setUserId("rasagna123");
		user.setListofShows(showlist);
        options = Optional.of(user);
	}

	@Test
	@Rollback(true)
	public void testAddReminderSuccess() throws ShowAlreadyAdded {

		when(showrepo.save(user)).thenReturn(user);
		assertEquals(user, showrepo.save(user));
		verify(showrepo, times(1)).save(any());
	}	  

@Test
@Rollback(true)
public void testAddReminderFailure() throws ShowAlreadyAdded {

    when(showrepo.save(newUser)).thenReturn(null);
    assertEquals(newUser, showrepo.save(newUser));
    verify(showrepo, times(1)).save(any());
 }


@Test
@Rollback(true)
public void testGetAllShowsSuccess() {
	when(showrepo.findById("rasagna123")).thenReturn(options);
	assertEquals(showlist, showservice.viewShows("rasagna123"));
	
}


@Test
@Rollback(true)
public void deleteShowSuccess() throws ShowNotFound 
{
	when(showrepo.findById(user.getUserId())).thenReturn(options);
    when(showrepo.save(user)).thenReturn(user);
    boolean flag = showservice.deleteshow("Dance Plus", "rasagna123");
    assertEquals(true, flag);
    
}

@Test
@Rollback(true)
public void deleteShowFailure() throws ShowNotFound 
{
	when(showrepo.findById(user.getUserId())).thenReturn(null);
    when(showrepo.save(user)).thenReturn(user);
    
    assertThrows(
    		NullPointerException.class,
                () -> { showservice.deleteshow("Dance", "rasagna123"); });

}

}
