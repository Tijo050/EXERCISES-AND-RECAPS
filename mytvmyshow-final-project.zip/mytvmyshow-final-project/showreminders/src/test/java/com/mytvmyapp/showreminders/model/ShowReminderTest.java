package com.mytvmyapp.showreminders.model;

import java.time.LocalDateTime;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

public class ShowReminderTest
{
	private ShowReminder reminder;

	@BeforeEach
	public void setUp() throws Exception {
		
		reminder = new ShowReminder();
		
		reminder.setChannelName("Zee TV");
		reminder.setName("kuch kuch hotha hai");
		reminder.setType("movie");
		reminder.setScheduledTime("20/07/2021");
			
	}

	@AfterEach
	public void tearDown() throws Exception 
	{
		
	}

	@Test
	public void Beantest() {
		BeanTester beanTester = new BeanTester();
        beanTester.testBean(ShowReminder.class);
	}


	

}
