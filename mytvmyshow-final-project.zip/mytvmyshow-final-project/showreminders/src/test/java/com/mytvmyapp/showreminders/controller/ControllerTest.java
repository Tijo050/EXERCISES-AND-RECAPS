package com.mytvmyapp.showreminders.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.meanbean.test.BeanTester;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.http.MediaType;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mytvmyapp.showreminders.model.ShowReminder;
import com.mytvmyapp.showreminders.model.User;
import com.mytvmyapp.showreminders.service.ShowReminderService;

@SpringBootTest
public class ControllerTest 
{
	 private MockMvc mockMvc;
	 private User user;
	 private ShowReminder reminder,reminder1;
	 private List<ShowReminder> showlist;
	 private List<User> userList=new ArrayList<>();
	 
	 @MockBean
	 private  ShowReminderService service;
	 
	 @InjectMocks
	 private Controller controller;
	 
	 @BeforeEach
	    public void setUp() {
		 
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	        showlist=new ArrayList<>();
	        reminder = new ShowReminder();
		
			reminder.setChannelName("Zee TV");
			reminder.setName("kuch kuch hotha hai");
			reminder.setType("movie");
			reminder.setScheduledTime("20/07/2021");
			
			reminder1 = new ShowReminder("Maa TV","Dance","movie","20/07/2021");
			showlist.add(reminder);
			showlist.add(reminder1);
			user=new User("rasagna123",showlist);
			userList.add(user);
     }
	
	 public String asJsonString(Object obj) throws JsonProcessingException {
		 ObjectMapper objmap = new ObjectMapper();
		 String output = objmap.writeValueAsString(obj);
		 return output;
		 }
		 @Test
		 public void addShowSuccess() throws Exception {
		 when(service.add(reminder,"rasagna123")).thenReturn(reminder);
		 mockMvc.perform(MockMvcRequestBuilders.post("/mytv/myapp/addshow/rasagna123")
		 .contentType(MediaType.APPLICATION_JSON).content(asJsonString(reminder)))
		 .andExpect(MockMvcResultMatchers.status().isCreated())
		 .andDo(MockMvcResultHandlers.print());
		 }
		 @Test
		 public void getAllShowsSuccess() throws Exception{
		 when(service.viewShows("rasagna123")).thenReturn(showlist);
		 mockMvc.perform(get("/mytv/myapp/viewshows/rasagna123").contentType(MediaType.APPLICATION_JSON))
		 .andExpect(status().isOk())
		 .andDo(MockMvcResultHandlers.print());
		 }
		 @Test
		 public void getAllShowsFailure() throws Exception{
		 when(service.viewShows("rasagna")).thenReturn(null);
		 mockMvc.perform(get("/mytv/myapp//viewshows/rasagna").contentType(MediaType.APPLICATION_JSON))
		 .andExpect(status().isOk())
		 .andDo(MockMvcResultHandlers.print());
		 }
		 @Test
		 public void deleteShowSuccess() throws Exception {

		  when(service.deleteshow("kuch kuch hotha hai","rasagna123")).thenReturn(true);
		 mockMvc.perform(MockMvcRequestBuilders.delete("/mytv/myapp/remove/kuch kuch hotha hai/rasagna123")
		 .contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk())
		 .andDo(MockMvcResultHandlers.print());
		 }
		 @Test
		 public void deleteShowFailure() throws Exception {

		  when(service.deleteshow("kuch kuch ","rasagna123")).thenReturn(true);
		 mockMvc.perform(MockMvcRequestBuilders.delete("/mytv/myapp/remove/kuch kuch/rasagna123")
		 .contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk())
		 .andDo(MockMvcResultHandlers.print());
		 }

	 
}