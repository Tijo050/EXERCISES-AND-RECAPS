package com.mytvmyapp.showreminders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShowremindersApplicationTests {

	@Test
	void contextLoads() {
	}

}
