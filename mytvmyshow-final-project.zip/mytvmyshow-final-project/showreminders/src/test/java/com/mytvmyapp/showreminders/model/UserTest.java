package com.mytvmyapp.showreminders.model;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

public class UserTest 
{
	private User user;
	private ShowReminder reminder;
	private List<ShowReminder> remlist;
	
	@BeforeEach
	public void setUp() throws Exception {
		remlist=new ArrayList<>();
		reminder = new ShowReminder("Zee TV","kuch kuch hotha hai","movie","20/07/2021");
		remlist.add(reminder);
		user=new User();
		user.setUserId("rasagna@gmail.com");
		user.setListofShows(remlist);
	}

	@AfterEach
	public void tearDown() throws Exception 
	{
		
		
	}

	@Test
	public void Beantest() {
		BeanTester beanTester = new BeanTester();
        beanTester.testBean(User.class);
	}

	
	
	

}
