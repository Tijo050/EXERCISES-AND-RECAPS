package com.ustg.authorizationapp.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ustg.authorizationapp.exception.UserAlreadyExistsException;
import com.ustg.authorizationapp.exception.UserNotFoundException;
import com.ustg.authorizationapp.model.User;
import com.ustg.authorizationapp.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	
	
	@Autowired
	UserRepository userAuthRepository;
	
	public UserServiceImpl(UserRepository userAuthRepository) {
		this.userAuthRepository = userAuthRepository;
	}
	
    
    @Override
    public User validateUser(String email, String password) throws UserNotFoundException {
    	
    	User uprofile=userAuthRepository.findByEmailAndPassword(email, password);	
    	if(uprofile==null) 
    		throw new UserNotFoundException("Invalid credentials");
    	return uprofile;
    	
    }

	
    
    @Override
    public User saveUser(User user) throws UserAlreadyExistsException {
    	Optional<User> search = userAuthRepository.findById(user.getEmail());
		if(search.isPresent()) {
			throw new UserAlreadyExistsException("User Already Exists");
		}
		userAuthRepository.save(user);
		return user;
    }

}
