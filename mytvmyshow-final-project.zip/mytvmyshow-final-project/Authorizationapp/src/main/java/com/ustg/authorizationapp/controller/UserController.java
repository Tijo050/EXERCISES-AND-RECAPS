package com.ustg.authorizationapp.controller;

import java.util.Date;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ustg.authorizationapp.exception.UserAlreadyExistsException;
import com.ustg.authorizationapp.exception.UserNotFoundException;
import com.ustg.authorizationapp.model.User;
import com.ustg.authorizationapp.service.UserService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
@RequestMapping("auth/user")
@CrossOrigin("*")
public class UserController {
	@Autowired
	UserService userService;
	
	@PostMapping("/api/v1/auth/register")
	public ResponseEntity<?> addUser(@RequestBody() User user) {
		try {
			User addedUser = userService.saveUser(user);
			return new ResponseEntity<String>("User Created, \n"+addedUser, HttpStatus.CREATED);
		} catch (UserAlreadyExistsException e) {
			return new ResponseEntity<String>("User Already Exists", HttpStatus.CONFLICT);
		}
	}

	@PostMapping("/api/v1/auth/login")
	public ResponseEntity<?> validateUser(@RequestBody() User user) {
		try {
			User searchUser = userService.validateUser(user.getEmail(), user.getPassword());
			if (searchUser != null) {
				String mytoken = generateToken(user);
				HashMap<String, String> mymap = new HashMap<String, String>();
				mymap.put("token", mytoken);
				return new ResponseEntity<HashMap<String, String>>(mymap, HttpStatus.OK);
			} else
				return new ResponseEntity<String>("Invalid Credentials", HttpStatus.UNAUTHORIZED);
		} catch (UserNotFoundException e) {
			return new ResponseEntity<String>("User Not Found", HttpStatus.UNAUTHORIZED);
		}
	}
	
	private String generateToken(User user) {
		long expirytime = 10_000_000;
		return Jwts.builder().setSubject(user.getEmail()).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + expirytime))
				.signWith(SignatureAlgorithm.HS256, "myjwtkey").compact();
	}

	
}
