package com.ustg.authorizationapp.exception;

public class UserAlreadyExistsException extends Exception {

	public UserAlreadyExistsException(String message) {
        super(message);
    }
}
