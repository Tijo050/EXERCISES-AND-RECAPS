package com.ustg.authorizationapp.service;

import com.ustg.authorizationapp.exception.UserAlreadyExistsException;
import com.ustg.authorizationapp.exception.UserNotFoundException;
import com.ustg.authorizationapp.model.User;


public interface UserService {
	

    public User validateUser(String userId, String password) throws UserNotFoundException;

    User saveUser(User user) throws UserAlreadyExistsException;
}
