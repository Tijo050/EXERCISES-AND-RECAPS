package com.ustg.authorizationapp.controller;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.util.ArrayList;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


import com.ustg.authorizationapp.model.User;
import com.ustg.authorizationapp.service.UserService;
import com.ustg.authorizationapp.service.UserServiceImpl;


@RunWith(SpringRunner.class)
@WebMvcTest
public class UserControllerTest {

	@Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserServiceImpl userAuthService;

    
    private User user;

    @InjectMocks
    private UserController userAuthController;
    
    @BeforeEach
    public void setUp() throws Exception {

    	MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(userAuthController).build();


        user = new User();
        user.setEmail("ajay@ust");
        user.setFirstName("ajay");
        user.setLastName("kb");
        user.setPassword("123456");   
        user.setcPassword("123456");
    }
    
    @Test
    public void testRegisterUser() throws Exception {

        Mockito.when(userAuthService.saveUser(user)).thenReturn(user);
        mockMvc.perform(MockMvcRequestBuilders.post("/auth/user/api/v1/auth/register").contentType(MediaType.APPLICATION_JSON).content(convertobjtojson(user)))
                .andExpect(MockMvcResultMatchers.status().isCreated());
        
    }


   @Test
    public void testLoginUser() throws Exception {


        String email = "ajay@ust";
        String password = "123456";

        Mockito.when(userAuthService.saveUser(user)).thenReturn(user);
        Mockito.when(userAuthService.validateUser(email, password)).thenReturn(user);
        mockMvc.perform(MockMvcRequestBuilders.post("/auth/user/api/v1/auth/login").contentType(MediaType.APPLICATION_JSON).content(convertobjtojson(user)))
                .andExpect(MockMvcResultMatchers.status().isOk());
    
        
        }



    public String convertobjtojson(Object obj) throws JsonProcessingException {
		ObjectMapper objmap = new ObjectMapper();
		String output = objmap.writeValueAsString(obj);
		return output;
	}
    }

