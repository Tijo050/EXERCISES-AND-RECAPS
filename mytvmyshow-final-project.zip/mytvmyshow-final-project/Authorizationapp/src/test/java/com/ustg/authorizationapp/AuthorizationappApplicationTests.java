package com.ustg.authorizationapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationappApplicationTests {

	@Test
	void contextLoads() {
	}

}
