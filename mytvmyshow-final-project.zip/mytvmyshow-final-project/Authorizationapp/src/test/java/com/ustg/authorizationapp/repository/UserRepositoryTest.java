package com.ustg.authorizationapp.repository;



import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;



import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ustg.authorizationapp.model.User;



@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class UserRepositoryTest {

    
    @Autowired
    private UserRepository userRepository;
   
    
    private User user;
    
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        user = new User();
        user.setEmail("tijo@ust.com");
        user.setFirstName("test");
        user.setLastName("new");
        user.setPassword("123456");
        user.setcPassword("123456");
//        listuser=new ArrayList<>();
//		listuser.add(user);
		
        
    }

    


    
    @AfterEach
    public void tearDown() throws Exception {
    	userRepository.deleteAll();
    }


    @Test
	public void testRegisterUserSuccess() {
		
		userRepository.save(user);
		
		User expected=userRepository.findById(user.getEmail()).get();
		assertThat(user.getEmail(), is(expected.getEmail()));
	}
	
	@Test
	public void testLoginUserSuccess() {
		
		userRepository.save(user);
		
		User expected=userRepository.findById(user.getEmail()).get();
		
		assertThat(user.getEmail(), is(expected.getEmail()));
		
		
	}
	

}


    




