package com.ustg.authorizationapp.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


import com.ustg.authorizationapp.exception.UserAlreadyExistsException;
import com.ustg.authorizationapp.exception.UserNotFoundException;
import com.ustg.authorizationapp.model.User;
import com.ustg.authorizationapp.repository.UserRepository;


public class UserServiceImplTest {
    @Mock
     UserRepository userAuthRepository;
    User user;
    
    @InjectMocks
    UserServiceImpl userAuthServiceImpl;
    Optional<User> optional;
    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        user = new User();
        user.setEmail("tst@ust");
        user.setFirstName("tst");
        user.setLastName("new");
        user.setPassword("123456");
        user.setcPassword("123456");
        
		optional = Optional.of(user);
    }
    @Test
    public void testSaveUserSuccess() throws UserAlreadyExistsException {
        Mockito.when(userAuthRepository.save(user)).thenReturn(user);
        User actual = userAuthServiceImpl.saveUser(user);
       Assert.assertEquals(actual.getEmail(),"tst@ust");
    }
    @Test
    public void testSaveUserFailure() throws UserAlreadyExistsException {
       
        
        Mockito.when(userAuthRepository.findById("tst@ust")).thenReturn(optional);
        Mockito.when(userAuthRepository.save(user)).thenReturn(user);
        assertThrows(
        		UserAlreadyExistsException.class,
                    () -> { userAuthServiceImpl.saveUser(user); });
        
       
    }
	
    
}