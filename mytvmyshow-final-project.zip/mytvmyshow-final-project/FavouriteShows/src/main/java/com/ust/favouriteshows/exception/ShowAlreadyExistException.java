package com.ust.favouriteshows.exception;

public class ShowAlreadyExistException extends Exception {
	
	public ShowAlreadyExistException(String msg) 
	{
		super(msg);
	}

}
