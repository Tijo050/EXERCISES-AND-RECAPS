package com.ust.favouriteshows.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.favouriteshows.exception.ShowAlreadyExistException;
import com.ust.favouriteshows.exception.ShowNotFoundException;
import com.ust.favouriteshows.exception.UserNotFoundException;
import com.ust.favouriteshows.model.Show;
import com.ust.favouriteshows.service.ShowServiceIntf;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(path = "/api/v1/favouriteService")
public class FavouriteShowController {
	
	ShowServiceIntf showserv;
	
	@Autowired
	public FavouriteShowController(ShowServiceIntf showserv) {
		this.showserv=showserv;
	}
	
	@PostMapping("/addShow/{userId}")
	public ResponseEntity<?> addShow(@PathVariable("userId") String uid, @RequestBody Show show) throws ShowAlreadyExistException
	{
		
		try {
			   showserv.saveShowToMyWatchlist(uid,show);
			     return new ResponseEntity<String>("show added succesfully", HttpStatus.CREATED);   
			}catch(ShowAlreadyExistException e) {
				return new ResponseEntity<String>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}

	@DeleteMapping("/{userId}/{showname}")
	public ResponseEntity<?> deleteShow(@PathVariable("userId") String userId, @PathVariable("showname") String sid) throws UserNotFoundException, ShowNotFoundException
	{
		try {
			    showserv.deleteFavouriteShow(userId, sid);
		           return new ResponseEntity<String>("Deleted succssfully",HttpStatus.OK);
			 }catch(UserNotFoundException e) {
				   return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);
		}
		catch(ShowNotFoundException e)
		{
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	
	
	@GetMapping("/{userId}") 
	public ResponseEntity<?> getMyWatchList(@PathVariable("userId") String uid) throws ShowNotFoundException {
		 try {
			    List<Show> showList = showserv.getMyWatchListShows(uid);
		       return new ResponseEntity<List<Show>>(showList, HttpStatus.OK);
	         }catch(ShowNotFoundException e) {
	        	 return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	         }
	
	
	}
	
	
}

