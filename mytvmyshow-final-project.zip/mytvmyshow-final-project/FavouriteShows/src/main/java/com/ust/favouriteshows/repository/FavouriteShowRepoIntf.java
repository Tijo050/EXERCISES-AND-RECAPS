package com.ust.favouriteshows.repository;




import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.ust.favouriteshows.model.User;

@Repository
public interface FavouriteShowRepoIntf extends MongoRepository<User, String> {
	
}
