package com.ust.favouriteshows.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class User {

	@Id
	String userId;
	List<Show> favouriteShows;
	
	public User() {
		
	}
	
   public User(String userid, List<Show> favshow) {
		this.userId=userid;
		this.favouriteShows=favshow;
	   }
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<Show> getFavouriteShows() {
		return favouriteShows;
	}
	public void setFavouriteShows(List<Show> favouriteShows) {
		this.favouriteShows = favouriteShows;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", favouriteShows=" + favouriteShows + "]";
	}
	
}
