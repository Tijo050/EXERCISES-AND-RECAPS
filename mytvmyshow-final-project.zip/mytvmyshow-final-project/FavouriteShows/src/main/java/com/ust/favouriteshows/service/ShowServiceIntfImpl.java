package com.ust.favouriteshows.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ust.favouriteshows.exception.ShowAlreadyExistException;
import com.ust.favouriteshows.exception.ShowNotFoundException;
import com.ust.favouriteshows.exception.UserNotFoundException;
import com.ust.favouriteshows.model.Show;
import com.ust.favouriteshows.model.User;
import com.ust.favouriteshows.repository.FavouriteShowRepoIntf;

@Service
public class ShowServiceIntfImpl implements ShowServiceIntf{
	
	FavouriteShowRepoIntf favShowRepo;
	
	
	public ShowServiceIntfImpl(FavouriteShowRepoIntf favShowRepo) {
		super();
		this.favShowRepo=favShowRepo;
	}


	@Override
	public User saveShowToMyWatchlist(String userId,Show show) throws ShowAlreadyExistException {
		
		User result = null;
		System.out.println(userId);
		 Optional<User> exist = favShowRepo.findById(userId);
		  if(!exist.isPresent()) {
			   List<Show> showList = new ArrayList<Show>();
			   showList.add(show);
			   User user = new User();
			   user.setUserId(userId);
			   user.setFavouriteShows(showList);
			   favShowRepo.save(user);
			   result = user;
		  }else {
			  User existedUser = exist.get();
			  List<Show> existedShow = existedUser.getFavouriteShows();
			   for(Show s : existedShow) {
				   System.out.println(s);
				   System.out.println(existedShow);
				    if(s.getShowName().equalsIgnoreCase(show.getShowName())) {
				    	 throw new ShowAlreadyExistException("show already exist in favourites");
				    }
			   }
			   existedShow.add(show);
			   existedUser.setFavouriteShows(existedShow);
			   favShowRepo.save(existedUser);
			   result = existedUser;
		  }
		return result;
	}

//
//	@Override
//	public boolean deleteFavouriteShow(String userId, String showname) throws UserNotFoundException, ShowNotFoundException {
//		User user = findShow(userId);
//		
//		if(user == null) {
//			throw new UserNotFoundException("user id not registerd");
//		}else {
//			List<Show>  favouriteShow = user.getFavouriteShows();
//			boolean result = false;
//			Iterator<Show> showIterator = favouriteShow.iterator();
//			while(showIterator.hasNext()) {
//				Show showObj = showIterator.next();
//				if(showObj.getShowName().equals(showname)) {
//					showIterator.remove();
//					result = true;
//				}
//				
//			}
//			user.setFavouriteShows(favouriteShow);
//			favShowRepo.save(user);
//			if(!result) {
//				throw new ShowNotFoundException("Show not found  Exception");
//			}
//			return result;
//		}
//		
//	}


	@Override
	public User findShow(String userId) {
		Optional<User> userFound = favShowRepo.findById(userId);
		 if(userFound.isPresent()) {
			 return userFound.get();
		 }else
		return null;
	}


	@Override
	public List<Show> getMyWatchListShows(String userId) throws ShowNotFoundException {
		List<Show> shows;
		User userFound = findShow(userId);
		if(userFound == null) {
			throw new ShowNotFoundException("Show is not added to favourites");
		}else {
			shows = userFound.getFavouriteShows();
		}
		return shows;
	}


	@Override
	public boolean deleteFavouriteShow(String userId, String showname)
			throws UserNotFoundException, ShowNotFoundException {
		
		User user = findShow(userId);
		
		if(user == null) {
			throw new UserNotFoundException("user id not registerd");
		}else {
			List<Show>  favouriteShow = user.getFavouriteShows();
			boolean result = false;
			Iterator<Show> showIterator = favouriteShow.iterator();
			while(showIterator.hasNext()) {
				Show showObj = showIterator.next();
				if(showObj.getShowName().equals(showname)) {
					showIterator.remove();
					result = true;
				}
				
			}
			user.setFavouriteShows(favouriteShow);
			favShowRepo.save(user);
			if(!result) {
				throw new ShowNotFoundException("Show not found  Exception");
			}
			return result;
		}
		
	}

	

}
