package com.ust.favouriteshows.model;




public class Show {
	
	//private int id;
	String showName;
	String showType;
	String otherDetails;

	
	public Show() {
		
	}
	public Show(String showName, String showType, String otherDetails) {
//		this.id=id;
		this.showName = showName;
		this.showType = showType;
		this.otherDetails = otherDetails;

	}
//	public String getUserId() {
//		return userId;
//	}
//	public void setUserId(String userId) {
//		this.userId = userId;
//	}
//	public Integer getId() {
//		return id;
//	}
//	public void setId(Integer id) {
//		this.id = id;
//	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getShowType() {
		return showType;
	}
	public void setShowType(String showType) {
		this.showType = showType;
	}
	public String getOtherDetails() {
		return otherDetails;
	}
	public void setOtherDetails(String otherDetails) {
		this.otherDetails = otherDetails;
	}
	
	
	@Override
	public String toString() {
		return "Show [showName=" + showName + ", showType=" + showType + ", otherDetails=" + otherDetails
				 +  "]";
	}
	
	
	
}
