package com.ust.favouriteshows.exception;

public class ShowNotFoundException extends Exception {
	
	public ShowNotFoundException(String msg) 
	{
		super(msg);
	}

}
