package com.ust.favouriteshows.service;

import java.util.List;

import com.ust.favouriteshows.exception.ShowAlreadyExistException;
import com.ust.favouriteshows.exception.ShowNotFoundException;
import com.ust.favouriteshows.exception.UserNotFoundException;
import com.ust.favouriteshows.model.Show;
import com.ust.favouriteshows.model.User;

public interface ShowServiceIntf {
	
	User saveShowToMyWatchlist(String userId, Show show) throws ShowAlreadyExistException;
	
	boolean deleteFavouriteShow(String userId, String showname) throws UserNotFoundException, ShowNotFoundException;
	
	User findShow(String userId);
	
	List<Show> getMyWatchListShows(String userId) throws ShowNotFoundException;
	

}
