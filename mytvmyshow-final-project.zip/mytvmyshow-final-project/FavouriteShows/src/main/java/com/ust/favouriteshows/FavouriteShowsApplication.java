package com.ust.favouriteshows;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import com.ust.favouriteshows.filter.FavJwtFilter;


@EnableEurekaClient
@SpringBootApplication


//@EnableAutoConfiguration
//@ComponentScan(basePackages="com.ust.favouriteshows")
public class FavouriteShowsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FavouriteShowsApplication.class, args);
	}
	
	@Bean
	public FilterRegistrationBean<FavJwtFilter> jwtFilter()
	{
		UrlBasedCorsConfigurationSource urlconfig=new UrlBasedCorsConfigurationSource();
		CorsConfiguration config=new CorsConfiguration();
		config.setAllowCredentials(true);
		config.addAllowedOrigin("*");
		config.addAllowedMethod("*");
		config.addAllowedHeader("*");
		urlconfig.registerCorsConfiguration("/**", config);
		FilterRegistrationBean filterbean=new FilterRegistrationBean(new CorsFilter(urlconfig));
		filterbean.setFilter(new FavJwtFilter());
		filterbean.addUrlPatterns("/api/v1/favouriteService*");
		return filterbean;
	}

}
