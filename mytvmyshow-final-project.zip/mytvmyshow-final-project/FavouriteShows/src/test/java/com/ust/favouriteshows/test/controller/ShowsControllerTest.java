package com.ust.favouriteshows.test.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ust.favouriteshows.controller.FavouriteShowController;
import com.ust.favouriteshows.exception.ShowAlreadyExistException;
import com.ust.favouriteshows.exception.ShowNotFoundException;
import com.ust.favouriteshows.model.Show;
import com.ust.favouriteshows.model.User;
import com.ust.favouriteshows.service.ShowServiceIntf;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ShowsControllerTest {
	
	 private MockMvc mockMvc;
	 
	 @MockBean
	 private Show show;
	 @MockBean
	 private User user;
	 @MockBean
	    private ShowServiceIntf showService;
	 
	 @InjectMocks
	 private FavouriteShowController showController;
	 
	 private List<Show> showList;
	 
	 @BeforeEach
	    public void setUp() {

	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders.standaloneSetup(showController).build();
	        show = new Show();
	        
//	        show.setId(1001);
	        show.setShowName("Bawara Dil");
	        show.setShowType("TV Show");
	        show.setOtherDetails("Following a few misunderstandings, Siddhi and Shiva begin to loathe each other. Soon, their intense dislike turns into hatred and they get married with the determination to destroy each other.");

	        
	        showList = new ArrayList<>();
	        showList.add(show);
	        user = new User();
	        user.setUserId("sarala@ust.com");
	        user.setFavouriteShows(showList);
	               
	        
	 }
	 
	 @Test
	 public void addShowsSuccess() throws Exception {
		 when(showService.saveShowToMyWatchlist(any(),any())).thenReturn(user);
	        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/favouriteService/addShow/sarala@ust.com").contentType(MediaType.APPLICATION_JSON)
	                .content(asJsonString(show)))
	                .andExpect(MockMvcResultMatchers.status().isCreated())
	                .andDo(MockMvcResultHandlers.print());
	 }
	 
	 @Test
	 public void addShowsFailure() throws Exception {
		 when(showService.saveShowToMyWatchlist(any(),any())).thenThrow(ShowAlreadyExistException.class);
	        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/favouriteService/addShow/sarala@ust.com").contentType(MediaType.APPLICATION_JSON)
	                .content(asJsonString(show)))
	                .andExpect(MockMvcResultMatchers.status().isConflict())
	                .andDo(MockMvcResultHandlers.print());

	    }
	 
	 @Test
	    public void deleteShowsSuccess() throws Exception {

	        when(showService.deleteFavouriteShow("sarala@ust.com", show.getShowName())).thenReturn(true);
	        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/favouriteService/sarala@ust.com/Bawara Dil")
	                .contentType(MediaType.APPLICATION_JSON))
	                .andExpect(MockMvcResultMatchers.status().isOk())
	                .andDo(MockMvcResultHandlers.print());
	    }
	 
	 @Test
	    public void deleteShowsFailure() throws Exception {

	        when(showService.deleteFavouriteShow("sarala@ust.com",show.getShowName())).thenThrow(ShowNotFoundException.class);
	        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/favouriteService/sarala@ust.com/Bawara Dil")
	                .contentType(MediaType.APPLICATION_JSON))
	                .andExpect(MockMvcResultMatchers.status().isNotFound())
	                .andDo(MockMvcResultHandlers.print());

	    }
	 
	 
	 @Test
	public void getAllShowsByUserIdSuccess() throws Exception {
	        when(showService.getMyWatchListShows("sarala@ust.com")).thenReturn(showList);
	        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/favouriteService/sarala@ust.com")
	                .contentType(MediaType.APPLICATION_JSON))
	                .andExpect(MockMvcResultMatchers.status().isOk())
	                .andDo(MockMvcResultHandlers.print());
	    }
	 
	 @Test
	public void getAllNewsByUserIdFailure() throws Exception {
	        when(showService.getMyWatchListShows("sarala@ust.com")).thenThrow(ShowNotFoundException.class);
	        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/favouriteService/sarala@ust.com")
	                .contentType(MediaType.APPLICATION_JSON))
	                .andExpect(MockMvcResultMatchers.status().isNotFound())
	                .andDo(MockMvcResultHandlers.print());
	    }
	 
	 
	 private static String asJsonString(final Object obj) {
	        try {
	            return new ObjectMapper().writeValueAsString(obj);
	        } catch (Exception e) {
	            throw new RuntimeException(e);
	        }
	    }
}
