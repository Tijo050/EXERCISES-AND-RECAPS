package com.ust.favouriteshows.test.service;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.annotation.Rollback;

import com.ust.favouriteshows.exception.ShowAlreadyExistException;
import com.ust.favouriteshows.exception.ShowNotFoundException;
import com.ust.favouriteshows.exception.UserNotFoundException;
import com.ust.favouriteshows.model.Show;
import com.ust.favouriteshows.model.User;
import com.ust.favouriteshows.repository.FavouriteShowRepoIntf;
import com.ust.favouriteshows.service.ShowServiceIntfImpl;

public class ShowServiceTest {

	
	 private Show show;
	    private User user;
	    
	    @Mock
	    private FavouriteShowRepoIntf favShowRepo;
	    @InjectMocks
	    private ShowServiceIntfImpl showServiceImpl;
	    private List<Show> showList = null;
	    Optional<User> options;
	    
	    @BeforeEach
	    public void setUp() throws Exception {

	        MockitoAnnotations.initMocks(this);
	        show = new Show();
//			show.setId(1001);
			show.setShowName("Bawara Dil");
	        show.setShowType("TV Show");
	        show.setOtherDetails("Following a few misunderstandings, Siddhi and Shiva begin to loathe each other. Soon, their intense dislike turns into hatred and they get married with the determination to destroy each other.");

	        
	        showList = new ArrayList<>();
	        showList.add(show);
	        user = new User();
	        user.setUserId("sarala@ust.com");
	        user.setFavouriteShows(showList);
	        
	        options = Optional.of(user);
	    }
	    

	    @Test
	    @Rollback(true)
	    public void addShowSuccess() throws ShowAlreadyExistException {
	    	when(favShowRepo.save(user)).thenReturn(user);
	    	assertEquals(user, favShowRepo.save(user));
			verify(favShowRepo, times(1)).save(any());
	    }
	    
	    @Test
	    @Rollback(true)
	    public void addShowFailure() throws ShowAlreadyExistException {
	        when(favShowRepo.save(user)).thenReturn(null);
	        User status = showServiceImpl.saveShowToMyWatchlist(user.getUserId(), show);
	        assertEquals(user.getFavouriteShows(), status.getFavouriteShows());
	     }
	   
	    @Test
	    @Rollback(true)
	    public void getShowByEmailSuccess() throws UserNotFoundException, ShowNotFoundException {
	        when(favShowRepo.findById("sarala@ust.com")).thenReturn(options);
	        List<Show> fetechedshow = showServiceImpl.getMyWatchListShows(user.getUserId());
	        assertEquals(user.getFavouriteShows(), fetechedshow);
	    }
	   // @Test
	    @Rollback(true)
	    public void getShowByEmailFailure() throws ShowNotFoundException {
	        when(favShowRepo.findById("shamu@ust.com")).thenThrow(ShowNotFoundException.class);
	        
	        assertThrows(
	        		ShowNotFoundException.class,
	                    () -> { showServiceImpl.getMyWatchListShows("shamu@ust.com"); });
	       
	    }
	    
	    @Test
	    @Rollback(true)
	    public void deleteShowByEmailSuccess() throws UserNotFoundException, ShowNotFoundException {
	        when(favShowRepo.findById(user.getUserId())).thenReturn(options);
	        when(favShowRepo.save(user)).thenReturn(user);
	        boolean flag = showServiceImpl.deleteFavouriteShow("sarala@ust.com", show.getShowName());
	        assertEquals(true, flag);
	    }
	    @Test
	    @Rollback(true)
	    public void deleteShowByEmailFailure() {
	        when(favShowRepo.findById(user.getUserId())).thenReturn(null);
	        when(favShowRepo.save(user)).thenReturn(user);
	        
	        assertThrows(
	        		NullPointerException.class,
	                    () -> { showServiceImpl.deleteFavouriteShow("sarala@ust.com", show.getShowName()); });
	    
	    }
}
