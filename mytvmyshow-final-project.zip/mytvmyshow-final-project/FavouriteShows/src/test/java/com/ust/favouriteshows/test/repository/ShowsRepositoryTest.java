package com.ust.favouriteshows.test.repository;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ust.favouriteshows.model.Show;
import com.ust.favouriteshows.model.User;
import com.ust.favouriteshows.repository.FavouriteShowRepoIntf;

@ExtendWith(SpringExtension.class)
@DataMongoTest
public class ShowsRepositoryTest {
	
	@Autowired
	private FavouriteShowRepoIntf favShowRepo;
	
	private Show show;
	private User user = new User();
	
	private List<Show> showList = null;
	
	@BeforeEach
    public void setUp() throws Exception {
		
		show = new Show();
//		show.setId(1001);
		show.setShowName("Bawara Dil");
        show.setShowType("TV Show");
        show.setOtherDetails("Following a few misunderstandings, Siddhi and Shiva begin to loathe each other. Soon, their intense dislike turns into hatred and they get married with the determination to destroy each other.");

        
        showList = new ArrayList<>();
        showList.add(show);
        user = new User();
        user.setUserId("sarala@ust.com");
        user.setFavouriteShows(showList);
        
	}
	
	@AfterEach
    public void tearDown() throws Exception {
		favShowRepo.deleteAll();
    }
	
	//@Test
    public void AddShowTest() {
		favShowRepo.save(user);
        List<Show> allShows = favShowRepo.findById("sarala@ust.com").get().getFavouriteShows();
        assertThat(showList.get(0).getShowName(), is(allShows.get(0).getShowName()));
    }

	  //@Test
	    public void deleteShowTest() {
		    favShowRepo.save(user);
		    System.out.println(user);
	        List<Show> allShows = favShowRepo.findById("sarala@ust.com").get().getFavouriteShows();
	        assertThat(showList.get(0).getShowName(), is(allShows.get(0).getShowName()));
	        Iterator<Show> iterator = allShows.listIterator();
	        while (iterator.hasNext()) {
	            show = iterator.next();
	            if (show.getShowName().equalsIgnoreCase("Bawara Dil")) {
	                iterator.remove();
	            }
	        }

	        user.setFavouriteShows(allShows);
	        favShowRepo.save(user);
             
	        allShows = favShowRepo.findById("sarala@ust.com").get().getFavouriteShows();
	        System.out.println(allShows);

	        assertTrue(allShows.isEmpty());

	    }
	  
	 // @Test
	    public void getAllShowsByUserId() {

		  favShowRepo.save(user);
	        List<Show> allShow = favShowRepo.findById("sarala@ust.com").get().getFavouriteShows();
	        assertThat(allShow.size(),is(1));
	    }

}
