package com.ustg.reviews.service;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.annotation.Rollback;

import com.ustg.reviews.exception.ReviewsAlreadyAdded;
import com.ustg.reviews.exception.ReviewsNotFound;
import com.ustg.reviews.model.Review;
import com.ustg.reviews.model.User;
import com.ustg.reviews.repository.ReviewRepo;

public class ReviewServiceImplTest {
	@Mock
	private ReviewRepo revrepo;
	@InjectMocks
	private ReviewServiceImpl revservice;
	
	private User user,newUser;
	private Review review;
	private List<Review> revlist;
    Optional<User> options;
    private List<User> userList=new ArrayList<>();
    
	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	
		user=new User();
		revlist = new ArrayList<Review>();
		review = new Review("deekshu.06@gmail.com","Kumkum bhagya","good");
		Review review1 = new Review("deekshu.06@gmail.com","Vijay Super Singer","lovely singing");
		Review review2 = new Review("deekshu.06@gmail.com","Flashback","good memories");
		revlist.add(review1);
		revlist.add(review2);
		user.setUserId("deekshu.06@gmail.com");
		user.setListofReviews(revlist);
        options = Optional.of(user);
	}

	@Test
	@Rollback(true)
	public void testAddReviewSuccess() throws ReviewsAlreadyAdded {
when(revrepo.save(user)).thenReturn(user);
		assertEquals(user, revrepo.save(user));
		verify(revrepo, times(1)).save(any());
	}	  
@Test
@Rollback(true)
public void testAddReviewFailure() throws ReviewsAlreadyAdded {
	when(revrepo.save(newUser)).thenReturn(null);
    assertEquals(newUser, revrepo.save(newUser));
    verify(revrepo, times(1)).save(any());
 }
@Test
@Rollback(true)
public void testGetAllReviewsSuccess() {
	when(revrepo.findById("deekshu.06@gmail.com")).thenReturn(options);
	assertEquals(revlist, revservice.viewReviews("deekshu.06@gmail.com"));
	
}
@Test
@Rollback(true)
public void deleteReviewSuccess() throws ReviewsNotFound 
{
	when(revrepo.findById(user.getUserId())).thenReturn(options);
    when(revrepo.save(user)).thenReturn(user);
    boolean flag = revservice.deletereview("Flashback", "deekshu.06@gmail.com");
    assertEquals(true, flag);  
}
    @Test
@Rollback(true)
public void deleteReviewFailure() throws ReviewsNotFound 
{
	when(revrepo.findById(user.getUserId())).thenReturn(null);
    when(revrepo.save(user)).thenReturn(user);
    
    assertThrows(
    		NullPointerException.class,
    		() -> { revservice.deletereview("Dance", "deekshu.06@gmail.com"); });

}
}



