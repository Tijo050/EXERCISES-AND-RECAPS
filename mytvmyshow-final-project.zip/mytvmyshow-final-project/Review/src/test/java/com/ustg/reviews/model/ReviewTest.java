package com.ustg.reviews.model;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

public class ReviewTest {
	private Review review;

	@BeforeEach
	public void setUp() throws Exception {
		
		review = new Review();
		review.setUserId("deekshu.06@gmail.com");
		review.setShowName("Kumkum bhagya");
		review.setComment("good");
			
	}

	@AfterEach
	public void tearDown() throws Exception 
	{
		
	}

	@Test
	public void Beantest() {
		BeanTester beanTester = new BeanTester();
        beanTester.testBean(Review.class);
	}


	

}



