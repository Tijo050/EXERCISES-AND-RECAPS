package com.ustg.reviews.controller;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.http.MediaType;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ustg.reviews.model.Review;
import com.ustg.reviews.model.User;
import com.ustg.reviews.service.ReviewService;

@SpringBootTest
public class ControllerTests {
	private MockMvc mockMvc;
	 private User user;
	 private Review review,review1;
	 private List<Review> revlist;
	 private List<User> userList=new ArrayList<>();
	 
	 @MockBean
	 private  ReviewService service;
	 
	 @InjectMocks
	 private Controller controller;
	 
	 @BeforeEach
	    public void setUp() {
		 
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	        revlist=new ArrayList<>();
	        review = new Review();
			review.setUserId("deekshu.06@gmail.com");
			review.setShowName("Kumkum bhagya");
			review.setComment("good");
			
			review1 = new Review("deekshu.06@gmail.com","Vijay Super Singer","lovely singing");
			revlist.add(review);
			revlist.add(review1);
			user=new User("deekshu.06@gmail.com",revlist);
			userList.add(user);
   }
	
	 public String asJsonString(Object obj) throws JsonProcessingException {
			ObjectMapper objmap = new ObjectMapper();
			String output = objmap.writeValueAsString(obj);
			return output;
	 }
	 @Test
	    public void addReviewSuccess() throws Exception {
	        when(service.add(any())).thenReturn(review);
	        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/addreview")
	                .contentType(MediaType.APPLICATION_JSON).content(asJsonString(review)))
	                .andExpect(MockMvcResultMatchers.status().isCreated())
	                .andDo(MockMvcResultHandlers.print());
	    }

	 @Test
	    public void getAllReviewsSuccess() throws Exception{
	    	
		        when(service.viewReviews("deekshu.06@gmail.com")).thenReturn(revlist);
		        mockMvc.perform(get("/api/v1/viewreviews/deekshu.06@gmail.com").contentType(MediaType.APPLICATION_JSON))
		                .andExpect(status().isOk())
		                .andDo(MockMvcResultHandlers.print());
		    }
	 @Test
	    public void getAllReviewsFailure() throws Exception{
	    	
		        when(service.viewReviews("deekshu.06@gmail.com")).thenReturn(null);
		        mockMvc.perform(get("/api/v1/viewreviews/deekshu.06@gmail.com").contentType(MediaType.APPLICATION_JSON))
		                .andExpect(status().isOk())
		                .andDo(MockMvcResultHandlers.print());
		    }
	 @Test
	    public void deleteReviewSuccess() throws Exception {
		 when(service.deletereview("kumkum bhagya","deekshu.06@gmail.com")).thenReturn(true);
	        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/remove/kumkum bhagya/deekshu.06@gmail.com")
	                .contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk())
	                .andDo(MockMvcResultHandlers.print());
	    }
	 @Test
	    public void deleteReviewFailure() throws Exception {
		 when(service.deletereview("dance","deekshu.06@gmail.com")).thenReturn(true);
		 mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/remove/dance/deekshu.06@gmail.com")
	        		.contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk())
	             .andDo(MockMvcResultHandlers.print());
	    }

	 

}
