package com.ustg.reviews.model;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

public class UserTest {
	private User user;
	private Review review;
	private List<Review> revlist;
	
	@BeforeEach
	public void setUp() throws Exception {
		revlist=new ArrayList<>();
		review = new Review("deekshu.06@gmail.id","kumkum bhagya","good");
		revlist.add(review);
		user=new User();
		user.setUserId("deekshu.06@gmail.com");
		user.setListofReviews(revlist);
	}

	@AfterEach
	public void tearDown() throws Exception 
	{
		
		
	}

	@Test
	public void Beantest() {
		BeanTester beanTester = new BeanTester();
        beanTester.testBean(User.class);
	}

	
	
	

}



