package com.ustg.reviews.exception;

public class ReviewsAlreadyAdded extends Exception {
	
	public ReviewsAlreadyAdded(String message) 
	{
		super(message);
	}


}
