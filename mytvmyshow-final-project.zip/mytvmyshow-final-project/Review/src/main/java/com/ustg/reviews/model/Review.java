package com.ustg.reviews.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Review {

	String userId;
	String showName;
	String comment;
	
	public Review() 
	{

	}
	public Review(String userId, String showName,String comment) {
		super();
		this.userId = userId;
		this.showName = showName;
		this.comment=comment;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	@Override
	public String toString() {
		return "Review [userId=" + userId + ", showName=" + showName + ", comment=" + comment + "]";
	}
	


	
	
	
}
