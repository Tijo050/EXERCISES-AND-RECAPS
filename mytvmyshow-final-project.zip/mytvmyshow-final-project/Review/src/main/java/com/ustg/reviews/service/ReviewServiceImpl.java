package com.ustg.reviews.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ustg.reviews.exception.ReviewsAlreadyAdded;
import com.ustg.reviews.exception.ReviewsNotFound;
import com.ustg.reviews.model.Review;
import com.ustg.reviews.repository.ReviewRepo;
import com.ustg.reviews.model.User;

@Service
public class ReviewServiceImpl implements ReviewService{

	@Autowired
	ReviewRepo repo;
	
	@Override
	public Review add(Review review) throws ReviewsAlreadyAdded {
		// TODO Auto-generated method stub
		User user;
		Optional<User> userexist=repo.findById(review.getUserId());
		if(userexist.isPresent())
		{
			 user=userexist.get();
		}
		else
		{
			 user=new User();
			user.setUserId(review.getUserId());
		}
		
		List<Review> listofreviews=user.getListofReviews();	
		if(listofreviews==null || listofreviews.isEmpty())
		{
			listofreviews = new ArrayList<>();	
		}
		Optional<Review>reviews=listofreviews.stream().filter(obj ->obj.getShowName().equalsIgnoreCase(review.getShowName())).findAny();
		if(reviews.isPresent())
			throw new ReviewsAlreadyAdded("Review Already Exists");
		
			Review result=new Review();
			result.setShowName(review.getShowName());
			result.setComment(review.getComment());
			
			result.setUserId(review.getUserId());
		
			listofreviews.add(result);
			user.setListofReviews(listofreviews);
			repo.save(user);
			return result;
	}
	

	@Override
	public List<Review> viewReviews(String userId) {
		List<Review> review=null;
		Optional<User> userexist=repo.findById(userId);
		if(userexist.isPresent())
		{
			User user=userexist.get();
			 review=user.getListofReviews();
		}
		return review;
	}
	
	@Override
	public boolean deletereview(String showName, String userId) throws ReviewsNotFound {
		List<Review> review=null;
		Review sreview=null;
		User user=null;
		Optional<User> userexist=repo.findById(userId);
		if(userexist.isPresent())
		{
			 user=userexist.get();
			review=user.getListofReviews();
		}
		if(review!=null)
		{
			Optional<Review> result=review.stream().filter(obj -> obj.getShowName().equalsIgnoreCase(showName)).findAny();
			if(result.isPresent())
			{
				sreview=result.get();
				
			}
		}
		
		
		if(sreview==null)
			throw new ReviewsNotFound("review not found");
		
		review.remove(sreview);
		user.setListofReviews(review);
		repo.save(user);
		return true;	
	}
}




