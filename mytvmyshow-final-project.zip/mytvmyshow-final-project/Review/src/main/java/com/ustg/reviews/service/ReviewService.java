package com.ustg.reviews.service;

import java.util.List;

import com.ustg.reviews.exception.ReviewsAlreadyAdded;
import com.ustg.reviews.exception.ReviewsNotFound;
import com.ustg.reviews.model.Review;

public interface ReviewService {
	
	Review add(Review review) throws ReviewsAlreadyAdded;
List<Review> viewReviews(String userId);
boolean deletereview(String showName,String userId) throws ReviewsNotFound;



}
