package com.ustg.reviews.exception;

public class ReviewsNotFound extends Exception {
	public ReviewsNotFound(String message) 
	{
		super(message);
	}


}
