package com.ustg.reviews.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.ustg.reviews.exception.ReviewsAlreadyAdded;
import com.ustg.reviews.exception.ReviewsNotFound;
import com.ustg.reviews.model.Review;
import com.ustg.reviews.service.ReviewService;

@RestController
@CrossOrigin("*")
@RequestMapping(path = "/api/v1")
public class Controller {
	
	@Autowired
	ReviewService service;
	@PostMapping("/addreview")
	public ResponseEntity<?> addReview(@RequestBody Review review)
	{
		Review result;
		try
		{	
		result=service.add(review);
		return new ResponseEntity<Review>(result,HttpStatus.CREATED);
		}
		catch (ReviewsAlreadyAdded e) 
		{
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}
	@GetMapping("/viewreviews/{userId}")
	public ResponseEntity<?> viewreviews(@PathVariable("userId") String userId)
	{
	List<Review> resultlist=service.viewReviews(userId);
	System.out.println(resultlist);
	return new ResponseEntity<>(resultlist,HttpStatus.OK);
	}
	
	@DeleteMapping("/remove/{showName}/{userId}")
	public ResponseEntity<?> removereview(@PathVariable("showName") String showname,@PathVariable("userId") String user)
	{
		try
		{
		service.deletereview(showname,user);
		return new ResponseEntity<String>("Removed Successfully",HttpStatus.OK);
		}
		catch(ReviewsNotFound e)
		{
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);

		}

	}


	
	
}


