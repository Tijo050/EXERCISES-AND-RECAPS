package com.ustg.reviews.model;


import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document
public class User {
	@Id
	String userId;
	List<Review> listofReviews;
	
	public User() 
	{
		
	}
	
	public User(String userId, List<Review> listofReviews) {
		super();
		this.userId = userId;
		this.listofReviews = listofReviews;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<Review> getListofReviews() {
		return listofReviews;
	}

	public void setListofReviews(List<Review> listofReviews) {
		this.listofReviews = listofReviews;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", listofReviews=" + listofReviews + "]";
	}
	

}
