import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private httpcli: HttpClient) { }
 
 registerUser(data: any): Observable<any> {
 console.log(data);
 return this.httpcli.post('http://localhost:8080/auth/user/api/v1/auth/register',data,{responseType: 'text'});
 }
 
 authenticateUser(data: any): Observable<any> {
 return this.httpcli.post('http://localhost:8080/auth/user/api/v1/auth/login', data);
 }
 
 setBearerToken(token: any) {
 sessionStorage.setItem('mytoken', token);
 }
 
 getBearerToken(): any {
 return sessionStorage.getItem('mytoken');
 }
 
 isUserAuthenticated(token: any): Promise<boolean> {
 return this.httpcli.post('http://localhost:8080/auth/user//api/v1/auth/login', {},
 { headers: new HttpHeaders().set('Authorization', `Bearer ${token}`) }
 ) .pipe // passing the collection {isAuthenticated:true or false} to pipe & map
 (map(
 (res: any) => {
 return (res['']);
 }) // returning value for key isAuthenticated
 ).toPromise();
 }
 
}
