import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { review } from 'src/review';

 

@Injectable({
  providedIn: 'root'
})
export class ReviewService {
  comments: Array<review>;
  reviewSubject: BehaviorSubject<Array<review>>;
  token: any;
  constructor(private httpClient: HttpClient) {
    this.comments=[];
    this.reviewSubject = new BehaviorSubject<Array<review>>([]);
  }
  addReviews(review:any): Observable<any> {
    this.token = sessionStorage.getItem("mytoken");
    console.log(this.token);
    console.log(review);
    return this.httpClient.post(`http://localhost:9092/api/v1/addreview`, review,{
       headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`) });
      
 }
//  fetchReviewsFromServer(): Observable<Array<review>> {
//   return this.httpClient.get<Array<review>>('http://localhost:9093/api/v1/addreview', {
//     // headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`)
//   });
// }

// getReviews(): BehaviorSubject<Array<review>> {
//   this.fetchReviewsFromServer().subscribe(
//     data => {
//       this.comments = data;
//       this.reviewSubject.next(this.comments);
//     },
//     err => { console.log(err); }
//   );

//   return this.reviewSubject;
// }

 

  getReviews(userId: string): Observable<any> {
  
    this.token = sessionStorage.getItem("mytoken");
    return this.httpClient.get<Array<any>>(`http://localhost:9092/api/v1/viewreviews/${userId}`,{
       headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`) });
  
}
  deleteReview(id: string,userId: string): Observable<any> {
    this.token = sessionStorage.getItem("mytoken");
    return this.httpClient.delete(`http://localhost:9092/api/v1/remove/${id}/${userId}`, { responseType: 'text',
       headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`) });
    
  }
}




