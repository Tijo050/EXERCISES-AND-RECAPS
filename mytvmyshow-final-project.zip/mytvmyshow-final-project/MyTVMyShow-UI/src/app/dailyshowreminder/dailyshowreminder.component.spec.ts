import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DailyshowreminderComponent } from './dailyshowreminder.component';

describe('DailyshowreminderComponent', () => {
  let component: DailyshowreminderComponent;
  let fixture: ComponentFixture<DailyshowreminderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DailyshowreminderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DailyshowreminderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
