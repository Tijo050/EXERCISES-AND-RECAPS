import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RouterService } from 'src/services/router.service';
import { ShowreminderService } from '../showreminder.service';
@Component({
  selector: 'app-dailyshowreminder',
  templateUrl: './dailyshowreminder.component.html',
  styleUrls: ['./dailyshowreminder.component.css']
})
export class DailyshowreminderComponent implements OnInit {
  shows: any;
  uid: any;
  q: any;
  constructor(private service :ShowreminderService,private router: RouterService,private snackBar: MatSnackBar) { }
  ngOnInit(): void {
    this.displayReminders();
  }
  displayReminders() {
     this.uid=sessionStorage.getItem("useremail");
        this.service.getReminders(this.uid).subscribe(
          (res) => {
            console.log(res);
            this.shows=res;
          }
        );
  }
  delReminder(name: string){
    console.log(name);
    this.uid =sessionStorage.getItem("useremail");
    this.service.deleteReminder(name,this.uid).subscribe(
      (res) => {
        this.openSnackBar("Show Removed From Reminders!", "Ok");
        window.location.reload();
      },
      (err)=>{
        this.openSnackBar("Failed To Remove Show From Reminders!", "Ok");
      }
    );
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 4000,
      panelClass: ['myclass']
    });
  }

  logOut(){
    sessionStorage.clear();
    this.router.openHome();
  }
}
