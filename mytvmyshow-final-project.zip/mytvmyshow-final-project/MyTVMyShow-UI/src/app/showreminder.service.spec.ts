import { TestBed } from '@angular/core/testing';

import { ShowreminderService } from './showreminder.service';

describe('ShowreminderService', () => {
  let service: ShowreminderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ShowreminderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
