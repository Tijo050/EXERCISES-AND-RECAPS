import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RouterService } from 'src/services/router.service';
import { TodaySchServeService } from 'src/services/today-sch-serve.service';

@Component({
  selector: 'app-channels',
  templateUrl: './channels.component.html',
  styleUrls: ['./channels.component.css']
})
export class ChannelsComponent implements OnInit {

  channelArray: any;
  errorMessage: string='';
  p : any;
  q: any;
  imageUrls: any[]=[]; 
  imageUrlsLifestyle: any[] = ["../../assets/images/TLC-HD.png","../../assets/images/Food Food channel.jpg",
                        "../../assets/images/Good Times.jpg","../../assets/images/travel-xp-hd-logo.jpg","../../assets/images/tlc-logo.png",
                         "../../assets/images/etv-abhiruchi.jpg","../../assets/images/tlc-logo.png","../../assets/images/kaumudy.jpg","../../assets/images/propex tv.jpg",
                        "../../assets/images/Astroflix.jpg"]
  imageUrlsEnt: any[]=["../../assets/images/Entertain/colorsHD.jpg","../../assets/images/Entertain/sonyhd.png","../../assets/images/Entertain/zee-tv-hd-logo-300x300.jpg",
                        "../../assets/images/Entertain/Sony_SAB.png","../../assets/images/Entertain/And_TV_HD.png","../../assets/images/Entertain/jio.webp"]; 
  imageUrlsMovie: any[]=["../../assets/images/Sony_Max_HD_2015.png","../../assets/images/HBO.jpg","../../assets/images/zee-cinema-hd-logo-300x300.jpg",
                         "../../assets/images/Colors_TV.jpg","../../assets/images/sony-pix-hd.jpg","../../assets/images/WB.png"];                      
  imageUrlsKids: any[]=["../../assets/images/kids/nick channel.png","../../assets/images/kids/pogo channel.jpg","../../assets/images/kids/cartoon network logo.png",
                        "../../assets/images/kids/sonic hindi logo.jpg","../../assets/images/kids/Sony_Yay_Logo.jpg","../../assets/images/kids/nickeldeon logo.png"]; 
  imageUrlsSports: any[]=["../../assets/images/SPORTS/jio cricket hd logo.jpg","../../assets/images/SPORTS/Sony_SIX_ hd logo.png","../../assets/images/SPORTS/Ten_1 logo.png",
                          "../../assets/images/SPORTS/TEN 2 HD.jpg","../../assets/images/SPORTS/TEN 3 HD.png","../../assets/images/SPORTS/Eurosport_hd_.png"];
  imageUrlsMusic: any[]=["../../assets/images/Music/1280px-MTV-Logo.png","../../assets/images/Music/MTV_Beats_HD-0.jpg","../../assets/images/Music/mastiii.jpg",
                         "../../assets/images/Music/sun-music-hd.png","../../assets/images/Music/Zing.jpg","../../assets/images/Music/9xm.jpg"]; 
  imageUrlsNews: any[]=["../../assets/images/News/Times_Now_2010.png","../../assets/images/News/1521091999_44idr8_aaj-tak-hd-logo.jpg","../../assets/images/News/BBC-marathi.png",
                        "../../assets/images/News/ABPNews_2016.jpg","../../assets/images/News/cnn-news-18.png","../../assets/images/News/Republic TV.png"]; 
  imageUrlsInfo: any[]=["../../assets/images/Infotain/discovery-world-channel-logo.png","../../assets/images/Infotain/Sony_BBC_Earth.jpg","../../assets/images/Infotain/history-tv18-logo-vector.png",
                         "../../assets/images/Infotain/FYI_TV18_HD_Background.jpg","../../assets/images/Infotain/animal-planet-hd-logo-300x300.jpg","../../assets/images/Infotain/TRAVEL-XP-HD.jpg"];  
  constructor(private myserv: TodaySchServeService, private route: ActivatedRoute,private routeserv: RouterService) { }

  ngOnInit(): void {
    this.displayChannels();
  }


  displayChannels(){
    this.route.params.subscribe((params)=> {
      
      
       if(
         params.cate === 'Entertainment' || params.cate === 'Movies' || params.cate === 'Kids' || params.cate === 'Sports' ||
         params.cate === 'Lifestyle' || params.cate === 'Infotainment' || params.cate === 'News' || params.cate === 'Music' ||
           (params.cate == 'Entertainment' && params.cate !== null)
      ) {
            this.myserv.fetchChannels(params.cate) 
            .subscribe(
              (res: any) => {
                  console.log(res);
                 this.channelArray = res;
              },
              (err) => {
                      this.errorMessage=err.message;}
            )
            sessionStorage.setItem("cate",params.cate)
            if(params.cate === 'Entertainment') {
              this.imageUrls=this.imageUrlsEnt;
           }else if(params.cate === 'Movies' ) {
             this.imageUrls=this.imageUrlsMovie;
           }else if(params.cate === 'Kids') {
             this.imageUrls=this.imageUrlsKids;
           }else if(params.cate === 'Sports') {
             this.imageUrls=this.imageUrlsSports;
           }else if(params.cate === 'Lifestyle') {
             this.imageUrls=this.imageUrlsLifestyle;
           }else if(params.cate === 'Infotainment') {
             this.imageUrls=this.imageUrlsInfo;
           }else if(params.cate === 'News' ) {
             this.imageUrls=this.imageUrlsNews;
           }else if(params.cate === 'Music' ) {
             this.imageUrls=this.imageUrlsMusic;
           }
          }
          
     }
    );
   
}
 
OnMatCard(channelname: any) {
  sessionStorage.setItem("channel",channelname);
  this.routeserv.openShows();
}


}
