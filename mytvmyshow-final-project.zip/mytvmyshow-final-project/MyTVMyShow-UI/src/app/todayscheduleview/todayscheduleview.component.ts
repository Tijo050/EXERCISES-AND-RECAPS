import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
 import { Show } from 'src/tvShow';
import { TodaySchServeService } from '../../services/today-sch-serve.service';

@Component({
  selector: 'app-todayscheduleview',
  templateUrl: './todayscheduleview.component.html',
  styleUrls: ['./todayscheduleview.component.css']
})
export class TodayscheduleviewComponent implements OnInit {
 
   cate: any;
   channelArray: Array<String>=[];
   channellangArray: Array<String>=[];
  rescoll : any;
  q: any;
  
  arrayTime=['00:00:00','01:00:00','02:00:00','03:00:00','04:00:00','05:00:00','06:00:00','07:00:00','08:00:00','09:00:00',
              '10:00:00','11:00:00','12:00:00','13:00:00','14:00:00','15:00:00','16:00:00','17:00:00','18:00:00','19:00:00','20:00:00','21:00:00',
               '23:00:00']

  channelsArray : any=['Colors HD', 'Sony HD', 'Zee TV HD', 'Polimer News', 'Zee Tamil', 'Colors Tamil HD',
                        'TV9 Telugu News', 'Zee Telugu', 'Zee Cinemalu',
   'Gemini Movies HD','BBC Marathi', 'ABP Majha', 'Zee Marathi','Zee Bangla', 'Colors Bengali HD']            
  
   channelForm = new FormGroup({
       channelname: new FormControl()
                });
    channelname= new FormControl("",Validators.required);
    showarry: Array<Show>= [];
  // showarry: any;
   lang: any;
   categories: Array<String>=[];
  languages: Array<String>=[];
  errorMessage: String='';
  constructor(private showserv: TodaySchServeService) {
    
   }

  ngOnInit(): void {
    // this.getShowsByChannelName();
    this.showserv.fetchSchedule("Zee TV HD").subscribe(
      (res: any) => {
        this.rescoll = res;
        console.log(this.rescoll);
        for(let i=0;i<=24;i++) {
            if(this.rescoll[this.arrayTime[i]]!=null){
         this.showarry.push(this.rescoll[this.arrayTime[i]]);
          }
      }
      console.log(this.showarry) 
     },
     (err) => {
        this.errorMessage= err.message;
     }
 )


    this.showserv.fetchCat().subscribe(
      // (res) => console.log(res)
      (res: any)  => { this.categories = res["categories"];
       this.languages = res["languages"] }   
  )
  this.displayChannels()
  
  }

  // getShowsByChannelName()
  // {
  //   this.showarry =[];
  //   this.showserv.fetchSchedule(this.channelname)
  //   .subscribe(
  //     (res: any) => {
  //        this.rescoll = res;
  //        console.log(this.rescoll);
  //        for(let i=0;i<=24;i++) {
  //            if(this.rescoll[this.arrayTime[i]]!=null){
  //         this.showarry.push(this.rescoll[this.arrayTime[i]]);
  //          }
  //      }
  //      console.log(this.showarry) 
  //     },
  //     (err) => {
  //        this.errorMessage= err.message;
  //     }
  // )

  //  }

displayChannels(){
   this.showserv.fetchChannels(this.cate)
  //  .subscribe(
  //   // (res) => { console.log(res) }
  //    (res: any) => { this.channelArray = res },
  //    err => { this.errorMessage = err.message }
  //    )
      // console.log(this.channelArray)
}

  displayChannelsByLang() {
    this.showserv.getChannels(this.lang).subscribe(
      
       res => { 
         console.log(res) }
        // this.channellangArray = res}
    )
    console.log(this.channellangArray)
  }


  // getShowsByChannelName(){
  //    this.showserv.fetchSchedule(this.channelname).subscribe(
  //      (res: any) => { this.showarry}
  //    )
  // }
  

  onSelectCategory(eve:any){
    this.showarry =[];
    this.showserv.fetchSchedule(eve)
    .subscribe(
      (res: any) => {
         this.rescoll = res;
         console.log(this.rescoll);
         for(let i=0;i<=24;i++) {
             if(this.rescoll[this.arrayTime[i]]!=null){
          this.showarry.push(this.rescoll[this.arrayTime[i]]);
           }
       }
       console.log(this.showarry) 
      },
      (err) => {
         this.errorMessage= err.message;
      }
  )


  }
}
