import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TodayscheduleviewComponent } from './todayscheduleview.component';

describe('TodayscheduleviewComponent', () => {
  let component: TodayscheduleviewComponent;
  let fixture: ComponentFixture<TodayscheduleviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TodayscheduleviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TodayscheduleviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
