import { Component, OnInit } from '@angular/core';
import { RouterService } from 'src/services/router.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  token: any;
  ifLogin: boolean= false;
  
  constructor(private router: RouterService) { }

  ngOnInit(): void {
    this.token =  sessionStorage.getItem('mytoken')
    console.log(this.token);
   if(this.token!=null){
   
     this.ifLogin = true;
   
   }
  }

   logOut(){

    sessionStorage.clear();
    this.router.openHome();
    location.reload();
  }

}
