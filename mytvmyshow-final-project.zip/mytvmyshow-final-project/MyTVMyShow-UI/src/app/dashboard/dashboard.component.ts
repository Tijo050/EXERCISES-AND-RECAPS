import { Component, OnInit } from '@angular/core';
import { RouterService } from 'src/services/router.service';
import { DashboardService } from '../dashboard.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  dashboardarray: Array<String>=[];
  imageUrls: any[] = ["../../assets/images/COLORS_HINDI.webp","assets/images/sonyhd.png",
                        "../../assets/images/zee_tv_hd.png","../../assets/images/sonysab1.png","../../assets/images/And_TV_HD.png",
                         "../../assets/images/jio.png","../../assets/images/rishteylogo.jpeg","../../assets/images/Zee_Anmol_old.jpg","../../assets/images/sonypallogo.jpeg",
                         "../../assets/images/sonysab.jpeg","../../assets/images/zee marati.jpg","../../assets/images/colorsmarati.webp","../../assets/images/colorskannada.jpg","../../assets/images/zeekannada.jpg",
                         "../../assets/images/zee_tv_hd.png"]
  constructor(private myserv:DashboardService, private route: RouterService) 
  {
    
  }
  
  ngOnInit(): void {
    this.myserv.fetchSchedule().subscribe(
      // (res) => console.log(res)
      (res: any)  => { 
          console.log(res)
       this.dashboardarray = res }   
  )
  }

  logOut(){
    sessionStorage.clear();
    this.route.openHome();
  }
  }
