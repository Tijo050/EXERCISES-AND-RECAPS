import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShowreminderService {
  token: any;
  constructor(private httpcli : HttpClient) 
  { 
 
  }
  
  getReminders(userId: string): Observable<any> {
  
    this.token = sessionStorage.getItem("mytoken");
    return (this.httpcli.get(`http://localhost:9090/mytv/myapp/viewshows/${userId}`, { 
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`) }));
  }
  deleteReminder(name: string,userId: string): Observable<any> 
  {
    console.log(name,userId);
    this.token = sessionStorage.getItem("mytoken");
    return (this.httpcli.delete(`http://localhost:9090/mytv/myapp/remove/${name}/${userId}`,
      { 
      responseType: 'text',
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`)
     }));
  }
  
}