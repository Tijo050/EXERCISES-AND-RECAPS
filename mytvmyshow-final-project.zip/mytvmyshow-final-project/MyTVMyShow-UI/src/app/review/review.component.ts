import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { review } from 'src/review';
import { RouterService } from 'src/services/router.service';
import { ReviewService } from '../review.service';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {
  reviewnew:review;
show: any;
  comments: Array<review> =[];
   uid: any;
   q: any;
   errMessage: string='';
  
   constructor(private service :ReviewService,private router: RouterService,private snackBar: MatSnackBar) { 
     this.reviewnew= new review();
     this.show=sessionStorage.getItem("showName");
   }
 
   ngOnInit(): void {
     this.displayReview();
   }
   displayReview() {
     console.log(this.uid);
     this.uid=sessionStorage.getItem("useremail");
        this.service.getReviews(this.uid).subscribe(
          (res) => {
            console.log(res);
            this.comments=res;
            console.log(this.comments);
          }
        );
  }
  
//   addReview(review:NgForm)
//   {
    
//     this.reviewnew={
//      userId:review.value.userId,
//     showName: this.show,
//      comment: review.value.comment
//    }
   
//   console.log(sessionStorage.getItem("showName"));
//     this.uid=sessionStorage.getItem("useremail");
//     if(this.reviewnew.showName !=='' && this.reviewnew.comment !== '' && this.reviewnew.userId !== '') {
         
//         this.service.addReviews(this.reviewnew).subscribe(
//           (res) => {
//             console.log(res);
//             this.comments=res;
//             console.log(this.comments);
//             window.location.reload();
//           }
//         );
//   } else {
//     this.errorMessage = 'Show name and comments both are required fields';
//   }
// }
// //console.log(review.value);
  

//   deleteReview(comment: any){
//     console.log(comment);

//     this.service.deleteReview(comment.showName,comment.userId).subscribe(
//       (res) => {
//         if(res=="Removed Successfully"){
//         this.openSnackBar("Comment  Removed From Reviews!", "Ok");
//         window.location.reload();
//         }
//       },
//       (err)=>{
//         this.openSnackBar("Failed To Remove comment  From Reviews!", "Ok");
//       }
//     );
//   }

//   openSnackBar(message: string, action: string) {
//     this.snackBar.open(message, action, {
//       duration: 4000,
//       panelClass: ['myclass']
//     });
//   }


addReview()
  {
    
  //   this.reviewnew={
  //    userId:review.value.userId,
  //   showName: this.show,
  //    comment: review.value.comment
  //  }
   
  console.log(sessionStorage.getItem("showName"));
    this.uid=sessionStorage.getItem("useremail");
    if(this.show !=='' && this.reviewnew.comment !== '' && this.reviewnew.userId !== '') {
              let data={ userId: this.reviewnew.userId, showName: this.show, comment: this.reviewnew.comment

              }
        this.service.addReviews(data).subscribe(
          (res) => {
            console.log(res);
            this.comments=res;
            console.log(this.comments);
            window.location.reload();
          }
        );
  } else {
    this.errMessage = 'Show name and comments both are required fields';
  }
}
//console.log(review.value);
  

  deleteReview(comment: any){
    console.log(comment);

    this.service.deleteReview(comment.showName,comment.userId).subscribe(
      (res) => {
        if(res=="Removed Successfully"){
        this.openSnackBar("Comment  Removed From Reviews!", "Ok");
        window.location.reload();
        }
      },
      (err)=>{
        this.openSnackBar("Failed To Remove comment  From Reviews!", "Ok");
      }
    );
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 4000,
      panelClass: ['myclass']
    });
  }


   
  logOut(){
    sessionStorage.clear();
    this.router.openHome();
  }

 
 }

 

