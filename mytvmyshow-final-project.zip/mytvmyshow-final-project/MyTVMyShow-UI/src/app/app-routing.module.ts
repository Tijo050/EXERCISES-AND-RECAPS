import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChannelsComponent } from './channels/channels.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ShowsComponent } from './shows/shows.component';
import { RegisterComponent } from './register/register.component';
import { TodayscheduleviewComponent } from './todayscheduleview/todayscheduleview.component';
import { DailyshowreminderComponent } from './dailyshowreminder/dailyshowreminder.component';
import { FavouriteShowsComponent } from './favourite-shows/favourite-shows.component';
import { ReviewComponent } from './review/review.component';
import { CanactivateGuard } from './canactivate.guard';

const routes: Routes = [
  {
    path:'login',
    component:LoginComponent
  },
    {
        path: 'register',
        component: RegisterComponent
     
  },
  {
    path:'home',
    component:HomeComponent
  },
  {
     path: 'dashboard',
     component: DashboardComponent,
     canActivate: [CanactivateGuard]
  },
 {
    path: 'dailyshowreminder',
    component: DailyshowreminderComponent,
    canActivate: [CanactivateGuard] 
 },
 {
    path: 'review',
   component: ReviewComponent,
   canActivate: [CanactivateGuard]
  },
  {
    path: 'favourites',
    component: FavouriteShowsComponent,
    canActivate: [CanactivateGuard]
  },

  {
    path: 'todaySchview',
    component: TodayscheduleviewComponent
  },

  {
    path: 'channels/:cate',
    component: ChannelsComponent
  },
  {
    path: 'viewShows',
    component: ShowsComponent
  },
  {
    path:'',
    redirectTo:'home',
    pathMatch:'full'
  }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
