import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private httpcli : HttpClient) { }
  fetchSchedule(): Observable<any>{
    const header = new HttpHeaders()
    .set('x-rapidapi-host', `indian-tv-schedule.p.rapidapi.com`)
    .set('x-rapidapi-key', `eaf082ab86msh59a6970b7387047p17c0d9jsn7a3dbcdd56e9`)

     return this.httpcli.get<any>(`https://indian-tv-schedule.p.rapidapi.com/searchChannel?cate=Entertainment`,
       {
           'headers': header
    } )  
}

}