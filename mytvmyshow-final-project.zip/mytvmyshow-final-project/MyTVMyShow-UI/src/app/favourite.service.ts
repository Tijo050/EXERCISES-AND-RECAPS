import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FavouriteService {
  token: any;
  constructor(private httpClient: HttpClient) {
  }
  

  getFavourites(userId: string): Observable<any> {
  
    this.token = sessionStorage.getItem("mytoken");
    return (this.httpClient.get(`http://localhost:9093/api/v1/favouriteService/${userId}`, { 
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`) }));
  }
  deleteFavourite(userId: string, id: string): Observable<any> {
    this.token = sessionStorage.getItem("mytoken");
    return (this.httpClient.delete(`http://localhost:9093/api/v1/favouriteService/${userId}/${id}`, { responseType: 'text',
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`) }));
  }
}