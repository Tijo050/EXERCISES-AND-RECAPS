import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  email = new FormControl('', Validators.required);
  firstName = new FormControl('', Validators.required);
  lastName = new FormControl('', Validators.required);
  password = new FormControl('', Validators.required);
  cPassword = new FormControl('', Validators.required);
  submitMessage: String='';
  
  constructor(private authserve: AuthenticationService) { 
  
  }
  
  ngOnInit(): void {
  // throw new Error('Method not implemented.');
  
  }
  
  
  
  loginSubmit() {
  if (this.email.valid && this.password.valid && this.firstName.valid && this.lastName.valid && this.cPassword.valid) {
  const data = {"email": this.email.value,"firstName": this.firstName.value,"lastName": this.lastName.value,"password": this.password.value,"cPassword": this.cPassword.value};
  this.authserve.registerUser(data).subscribe(res => {
  console.log("Registered" + res);
  alert("You are Registered Successfully");
  
  },
  (err) => { if (err.status==409) {
  // this.submitMessage = err.error.message;
  alert("Invalid Registration : User Already Exists");
  
   }
  // else if(this.email=== '' && this.password==='' && this.firstName==='' && this.lastName==='' && this.cPassword===''){
  // alert("Fill the details")
  // }
  });
  }
  
  }
 }
