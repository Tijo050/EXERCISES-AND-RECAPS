import { Component, OnInit } from '@angular/core';
import { TodaySchServeService } from 'src/services/today-sch-serve.service';
import { Show } from 'src/tvShow';
import { ShowService } from '../show.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RouterService } from 'src/services/router.service';
import { showReminders } from 'src/showreminder';
import { ReviewService } from '../review.service';

@Component({
  selector: 'app-shows',
  templateUrl: './shows.component.html',
  styleUrls: ['./shows.component.css']
})
export class ShowsComponent implements OnInit {

   showsArray: Array<Show>=[];
   data: any;
  errorMessage: string='';
   rescoll : any;
   arrayTime=['00:00:00','01:00:00','02:00:00','03:00:00','04:00:00','05:00:00','06:00:00','07:00:00','08:00:00','09:00:00',
   '10:00:00','11:00:00','12:00:00','13:00:00','14:00:00','15:00:00','16:00:00','17:00:00','18:00:00','19:00:00','20:00:00','21:00:00',
    '23:00:00']

    q: any;
    userId: any;
    favdata: any;
    channelName: any;
    reminderdata: any;
    comment: any;
    commentdata: any;
    cate: any=sessionStorage.getItem("cate");

  constructor(private myserv: TodaySchServeService, private showserv: ShowService, private snackBar: MatSnackBar,
                private rout: RouterService, private revserv: ReviewService) {

                     }

  ngOnInit(): void {
    this.viewShows();
  }

viewShows() {
   this.data = sessionStorage.getItem('channel');
  this.myserv.fetchSchedule(this.data).subscribe(

    (res: any) => { 
      this.rescoll = res;
         console.log(this.rescoll);
         for(let i=0;i<=24;i++) {
           if(this.rescoll[this.arrayTime[i]]!= null){
          this.showsArray.push(this.rescoll[this.arrayTime[i]]);
           }
      }
       console.log(this.showsArray) 
      },
      (err) => { if(err.status===500) {
                 this.errorMessage='Shows are not available';
      }}
  )
   }
   addFavourites(fav: Show) {
   
    this.userId = sessionStorage.getItem("useremail");
       this.favdata= { showName: fav.name, showType: fav.type, otherDetails: fav["other-details"]
            // userId: this.userId
          };
      if(this.userId!= null) {
    
        // fav.userId=this.userId;
         this.showserv.storeShows(this.favdata,this.userId).subscribe(
           (res) => {
                      //console.log(res);
              if(res == 'show already exist in favourites') {
                this.openSnackBar("show already exist in favourites!","OK");
              }else{
                 this.openSnackBar("Show added to favourites!","OK");
                    this.rout.openFavoriteShows();
              }

           },
           (err) => {
            if(err.status== 409){
              this.openSnackBar("Show already added","OK");
           }
          }
         )
      }else{
        this.openSnackBar("Please login to add show to favourites", "OK");
        this.rout.openLogin();
      }
   }


   openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 4000,
      panelClass: ['red-snackbar']
    });
  }

  addDailyRem(remData:Show,scheduletime:any)
  {
    
    console.log("rem called");
    console.log(scheduletime);

    this.userId = sessionStorage.getItem("useremail");
    this.channelName = sessionStorage.getItem("channel");

    this.reminderdata= { name: remData.name, type: remData.type, channelName: this.channelName,scheduledTime: scheduletime };
        //  userId: this.userId};
         if(this.userId!= null) 
         {
           this.showserv.storeReminders(this.reminderdata,this.userId).subscribe(
             (res) => {
                        console.log(res);
                if(res=="Show Already Exists")
                  this.openSnackBar("Show Already Exists","OK");
                else
                   this.openSnackBar("Show added to Reminders","OK");
                   this.rout.openDailyShowReminder();

  
             },
             (err) => {
                // if(err.status== 409){
               this.openSnackBar("Show already added","OK");
               }
            //  }
           )
        }else{
          this.openSnackBar("Please login to add show to REminders", "OK");
          this.rout.openLogin();
        }

  }
  
  addComment(comData: any) {
    console.log("comment called")
    this.userId = sessionStorage.getItem("useremail");
    // this.comment = sessionStorage.getItem("comment");
    // this.commentdata = {
    //   name: comData.name, type: comData.type, comment: this.comment,
    //   userId: this.userId
    // }; 
    console.log(this.userId);

    if (this.userId != null) {
      console.log(this.commentdata);
      sessionStorage.setItem("showName", comData.name);
      //  console.log("showName");
      this.rout.OpenReviews();
      // this.revserv.getReviews(this.commentdata).subscribe(
      //   (res) => {
      //     console.log(res);
      //     if (res == "Review Already Exists")
      //       this.openSnackBar("Comment Already Exists", "OK");
      //     else
      //       this.openSnackBar("Comment added", "OK");
      //     this.rout.openDashboard();

      //   },
      //   (err) => {
      //     console.log(err);
          //  if(err.status==500||err.status==409||err.status==201){
      //     this.openSnackBar("error while adding comments", "OK");
      //     //}
      //   }
      // )
    } else {
      this.openSnackBar("Please login to add comments to Reviews", "OK");
      this.rout.openLogin();
    }

  }
}
