import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Show } from 'src/tvShow';

@Injectable({
  providedIn: 'root'
})
export class ShowService {

  userId:any;

  constructor(private httpclient: HttpClient) { }



  storeShows(showData : any, userid: any) :Observable<any>
  {
      // console.log(showData);
    // let userId = sessionStorage.getItem("userid");
    let token = sessionStorage.getItem("mytoken");
    return this.httpclient.post(`http://localhost:9093/api/v1/favouriteService/addShow/${userid}`, showData, { responseType: 'text', 
    headers: new HttpHeaders().set('Authorization', `Bearer ${token}`) ,
   
    });
  }

  storeReminders(remData : any, userId: any) :Observable<any>

  {

    let token = sessionStorage.getItem("mytoken");
   

    return this.httpclient.post(`http://localhost:9090/mytv/myapp/addshow/${userId}`, remData, { responseType: 'text', 

    headers: new HttpHeaders().set('Authorization', `Bearer ${token}`) ,

   

    });
}
}
