import { Component, OnInit } from '@angular/core';
import { MyTvServiceService } from '../../services/my-tv-service.service';

@Component({
  selector: 'app-my-tv-view',
  templateUrl: './my-tv-view.component.html',
  styleUrls: ['./my-tv-view.component.css']
})
export class MyTvViewComponent implements OnInit {
  data: any;

  constructor(private tvser: MyTvServiceService) { }

  ngOnInit(): void {
  }

  // displayMovies()
  // {
  //   this.tvser.fetchMovies(this.data).subscribe(

  //     (res) => console.log(res)
  // )
  // }

}
