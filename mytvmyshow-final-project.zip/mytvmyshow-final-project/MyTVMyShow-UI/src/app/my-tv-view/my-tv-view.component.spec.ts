import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyTvViewComponent } from './my-tv-view.component';

describe('MyTvViewComponent', () => {
  let component: MyTvViewComponent;
  let fixture: ComponentFixture<MyTvViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyTvViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyTvViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
