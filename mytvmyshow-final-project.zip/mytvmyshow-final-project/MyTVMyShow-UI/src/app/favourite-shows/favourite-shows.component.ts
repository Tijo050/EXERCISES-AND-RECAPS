import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RouterService } from 'src/services/router.service';
import { Show } from 'src/tvShow';
import { FavouriteService } from '../favourite.service';

@Component({
  selector: 'app-favourite-shows',
  templateUrl: './favourite-shows.component.html',
  styleUrls: ['./favourite-shows.component.css']
})
export class FavouriteShowsComponent implements OnInit {

  shows: any;
  uid: any;
  q: any;
  constructor(private service :FavouriteService,private router: RouterService,private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.dislayFavourite()
  }

  dislayFavourite() {
     this.uid=sessionStorage.getItem("useremail");
        this.service.getFavourites(this.uid).subscribe(
          (res) => {
            console.log(res);
            this.shows=res;
            console.log(this.shows);
          }
        );
  }

  deleteFavourite(id: string){
    this.uid =sessionStorage.getItem("useremail");
    this.service.deleteFavourite(this.uid, id).subscribe(
      (res) => {
        this.openSnackBar("Show Removed From Favourites!", "Ok");
        window.location.reload();
      },
      (err)=>{
        this.openSnackBar("Failed To Remove Show From Favourites!", "Ok");
      }
    );
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 4000,
      panelClass: ['red-snackbar']
    });
  }

  logOut(){
    sessionStorage.clear();
    this.router.openHome();
  }

}

