import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RouterService } from 'src/services/router.service';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email = new FormControl('', Validators.required);
  password = new FormControl('', Validators.required);
  submitMessage: String = '';
  token: String = '';
  
  constructor(private authserve: AuthenticationService, private myroute: RouterService, private snackBar: MatSnackBar) { }
  ngOnInit(): void {
  
  }
  
  Validatename() {
  let result= "";
  if(this.email.touched && this.email.invalid)
  {
  result="email id can't be null"
  }
  return result;
  } 
  Validatepwd() {
  let res= "";
  if(this.password.touched && this.password.dirty)
  {
  if(this.password.hasError("Minlength"))
  res="password should be minimum 4 length"
  }
  return res;
  }
  
  
  loginSubmit() {
  console.log("welcome");
  const data = { email: this.email.value, password: this.password.value };
  sessionStorage.setItem("useremail",this.email.value);
  console.log(data);
  if(this.email.valid && this.password.valid ) {
  if(this.email.value==='tjadmin@123.com' && this.password.value==='root123') {
  this.authserve.authenticateUser(data).subscribe(
  (res) => {
  console.log(res);
  this.myroute.openDashboard();
  this.token = res['token'];
  this.authserve.setBearerToken(this.token);
  },
  (err) => {
  this.submitMessage = err.status;
  });
  } else {
  this.authserve.authenticateUser(data).subscribe(
  (res) => {
  console.log(res);
  // alert("Login Successfull");
   
  this.openSnackBar("Login success!!!","Continue to visit");
  location.reload();
  this.token = res['token'];
  this.authserve.setBearerToken(this.token);
  },
  (err) => {
  if(err.status == 401) {
  this.submitMessage = " Incorrect Email ID Or Password "
  }
  });
  }
  }
  
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 4000,
      panelClass: ['red-snackbar']
    });
  }
 }
