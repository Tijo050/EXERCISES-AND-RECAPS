import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RouterService } from 'src/services/router.service';
import { TodaySchServeService } from '../../services/today-sch-serve.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  channelArray: any;
  categories: Array<String>=[];
  languages: Array<String>=[];
  showCat: any[]=[];
  images: any[] =[]; 
  imageUrls: any[] = ["../../assets/images/family-mother-father-children-watching-260nw-1504958996.jpg","assets/images/movies-00.png",
                        "../../assets/images/Kids-TV.jpg","../../assets/images/sports.jpg","../../assets/images/lifestyle.jpg",
                         "../../assets/images/infotainment.png","../../assets/images/news.jpg","../../assets/images/music.jpg"]

  constructor(private myserv: TodaySchServeService, private routeserv: RouterService,private route: ActivatedRoute) { }

  ngOnInit(): void {
       this.displayChannels(); 
       this.getCategories();
  }


  getCategories()
  {
    this.myserv.fetchCat().subscribe(
      // (res) => console.log(res)
      (res: any)  => { this.categories = res["categories"];
       this.languages = res["languages"];
       this.categories.splice(6,1);
      this.categories }   
  )
  }
  displayChannels(){
       this.route.params.subscribe((params)=> {
         if(
           params.cate === 'Entertainment' || params.cate === 'Movies' || params.cate === 'Kids' || params.cate === 'Sports' ||
            params.cate === 'Lifestyle' || params.cate === 'Infotainment' || params.cate === 'News' || params.cate === 'Music' ||
              (params.cate === 'Entertainment' && params.cate !== null)
         ) {
               this.myserv.fetchChannels(params.cate)}
      //          .subscribe(
      //            (res) => {
      //              this.channelArray = res;
      //            }
      //          )}
       });
  }

 
  goToChannels() {
    this.routeserv.openChannels();
  }
  gotoTodaySchedule() {
    this.routeserv.openTodayScheduleview();
  }
  
 
}
