export class Category {
    "categories": string;
    "languages": string;
    constructor(){
        
    }
}