export class Show {
    "name": string;
    ['other-details']: string;
    "type": string;
    // "userId": string;

    constructor() {

    }
}