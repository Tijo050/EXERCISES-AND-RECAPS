export class showReminders
{
     "reminderId": String;
     "channelName": String;
     "showName": String;
     "scheduledTime": String;
      // "Day": String;
    constructor()
    {

    }
}