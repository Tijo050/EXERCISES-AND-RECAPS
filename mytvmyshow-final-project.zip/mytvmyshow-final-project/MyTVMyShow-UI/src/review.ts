export class review{
    "userId" : String ;
    "showName" : String;
    "comment" : String ;

    constructor()
    {

    }
  
}