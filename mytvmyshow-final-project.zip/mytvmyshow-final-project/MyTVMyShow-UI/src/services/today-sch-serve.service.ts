import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs';
import { Category } from 'src/tvCat';
import { tap } from 'rxjs/operators';
import { Show } from 'src/tvShow';

@Injectable({
  providedIn: 'root'
})
export class TodaySchServeService {

  scheduleArray: Array<Show>=[];
  showsSubject: BehaviorSubject<Array<Show>>;

  constructor(private httpcli : HttpClient) {
    this.showsSubject = new BehaviorSubject<Array<Show>>([]);

   }


  fetchSchedule(paramchannel: any) {
    const header = new HttpHeaders()
    .set('x-rapidapi-host', `indian-tv-schedule.p.rapidapi.com`)
    .set('x-rapidapi-key', `41383ed9d3msh154bcb6c4b25b93p1c145ajsne344fd2c5734`)

     return this.httpcli.get<any>(`https://indian-tv-schedule.p.rapidapi.com/Schedule?channel=${paramchannel}`,
       {
           'headers': header
    })
    // .subscribe(res => {
    //         this.scheduleArray = res;
    //         this.showsSubject.next(this.scheduleArray);
    // }, 
    // (err: any) => {
    //   this.showsSubject.error(err);
    // })

}

fetchCat(): Observable<Category[]>{
  const header = new HttpHeaders()
  .set('x-rapidapi-host', `indian-tv-schedule.p.rapidapi.com`)
  .set('x-rapidapi-key', `41383ed9d3msh154bcb6c4b25b93p1c145ajsne344fd2c5734`)

   return this.httpcli.get<Category[]>('https://indian-tv-schedule.p.rapidapi.com/getCategories',
     {
         'headers': header
  } )  
}

fetchChannels(paramcat: string){

  const header = new HttpHeaders()
  .set('x-rapidapi-host', `indian-tv-schedule.p.rapidapi.com`)
  .set('x-rapidapi-key', `41383ed9d3msh154bcb6c4b25b93p1c145ajsne344fd2c5734`)

   return this.httpcli.get<any[]>(`https://indian-tv-schedule.p.rapidapi.com/searchChannel?cate=${paramcat}`,
     {
         'headers': header
  })
  // .subscribe(res => {
  //           this.scheduleArray = res;
  //           this.showsSubject.next(this.scheduleArray);
  //   }, 
  //   (err: any) => {
  //     this.showsSubject.error(err);
  //   })  
}

getChannels(paramlang: String): Observable<any> {

  const header = new HttpHeaders()
  .set('x-rapidapi-host', `indian-tv-schedule.p.rapidapi.com`)
  .set('x-rapidapi-key', `41383ed9d3msh154bcb6c4b25b93p1c145ajsne344fd2c5734`)

   return this.httpcli.get<any[]>(`https://indian-tv-schedule.p.rapidapi.com/searchChannel?cate=${paramlang}`,
     {
         'headers': header
  } )  
}
}
