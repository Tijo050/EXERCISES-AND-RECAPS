import { TestBed } from '@angular/core/testing';

import { TodaySchServeService } from './today-sch-serve.service';

describe('TodaySchServeService', () => {
  let service: TodaySchServeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TodaySchServeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
