import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RouterService {

  constructor(private rouobj : Router) { }

  openLogin()
  {
    this.rouobj.navigate(['login'])
  }
  openRegister()
  {
    this.rouobj.navigate(['register'])
  }
  openHome()
  {
    this.rouobj.navigate(['home'])
  }
  openDashboard()
  {
    this.rouobj.navigate(['dashboard'])
    // location.reload();
  }
  openTodayScheduleview()
  {
    this.rouobj.navigate(['todaySchview'])
  }
  openChannels() 
  {
    this.rouobj.navigate(['channel'])
  }
  openShows()
  {
    this.rouobj.navigate(['viewShows'])
  }
  openDailyShowReminder()
  {
    this.rouobj.navigate(['dailyshowreminder'])
  }
  openFavoriteShows()
  {
    this.rouobj.navigate(['favourites'])
  }
  OpenReviews()
  {
    this.rouobj.navigate(['review'])
  }
}

