import { TestBed } from '@angular/core/testing';

import { MyTvServiceService } from './my-tv-service.service';

describe('MyTvServiceService', () => {
  let service: MyTvServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MyTvServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
