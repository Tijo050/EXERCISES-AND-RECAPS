import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthenticationService } from 'src/app/authentication.service';
import { Show } from 'src/tvShow';
// import { Movies } from 'src/tvShows';

@Injectable({
  providedIn: 'root'
})
export class MyTvServiceService {
   

  constructor(private httpcli : HttpClient, private auth: AuthenticationService) {
    }
      
//      fetchMovies(paramlang: any): Observable<any>{
//       const header = new HttpHeaders()
//       .set('x-rapidapi-host', `indian-tv-schedule.p.rapidapi.com`)
//       .set('x-rapidapi-key', `41383ed9d3msh154bcb6c4b25b93p1c145ajsne344fd2c5734`)
//       // .set('Content-Type','application/json')

//        return this.httpcli.get<any>(`https://indian-tv-schedule.p.rapidapi.com/GetTodaysMovies?lang=${paramlang}`,
//          {
//              'headers': header
//       } )  

// }

getFavourites(userid: any) :Observable<any> {
  
  return this.httpcli.get<Array<Show>>(`https://localhost:9093/api/v1/favouriteService/${userid}`,{
  headers: new HttpHeaders().set('Authorization', `Bearer ${this.auth.getBearerToken()}`)
});

}
}




