package com.example.projectmain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParentMyTvMyAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
