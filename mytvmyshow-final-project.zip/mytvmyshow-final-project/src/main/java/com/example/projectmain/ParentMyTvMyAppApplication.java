package com.example.projectmain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParentMyTvMyAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParentMyTvMyAppApplication.class, args);
	}

}
